import random
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np
import os
def select_colors(n):
    cols = [(0.31, 0.67, 0.56),(0.56, 0.71, 0.61),(0.93, 0.87, 0.76),(0.93, 0.75, 0.43),
              (0.85, 0.31, 0.20),(0.72, 0.71, 0.63),(0.27, 0.46, 0.48),(0.93, 0.84, 0.72),
              (0.99, 0.55, 0.35),(0.90, 0.95, 0.95),(0.56, 0.75, 0.88),(0.29, 0.45, 0.70),
              (0.80, 0.60, 0.49),(0.87, 0.75, 0.66),(0.99, 0.91, 0.84),(0.72, 0.72, 0.64),
              (203/255, 153/255, 126/255),(221/255, 190/255, 169/255),(253/255, 232/255, 213/255),
              (184/255, 183/255, 163/255),(229/255, 123/255, 127/255),(135/255, 187/255, 164/255),
              (144/255, 201/255, 230/255),(33/255, 158/255, 188/255),(255/255, 183/255, 3/255),
              (251/255, 132/255, 2/255),(48/255, 104/255, 141/255),(31/255, 146/255, 139/255),
              (53/255, 183/255, 119/255),(145/255 ,213/255 ,66/255)]
    colors = list(set(cols))
    selected_colors = random.sample(colors, n)
    return selected_colors

def main():
    # 读入数据
    # 1.读入文件各层的txt文件
    txts = []
    file_path = './solution/10j_5m_001/'
    for root, dirs, files in os.walk(file_path):
        for f in files:
            if f.endswith('.txt'):
                file_name = f.replace('.txt', '')
                if file_name.isdigit():
                    txts.append(f)
    # 2.对每层的txt,读入解
    for lays in range(len(txts)):
        solution_path = file_path + txts[lays]
        with open(solution_path) as file_object:
            lines = file_object.readlines()
        line_ins_info = lines[0].split()
        matrix_ins_info = [int(x) for x in line_ins_info]
        matrix_objects = []
        for i in range(1, len(lines)):      # 读取objects目标值
            if lines[i] == '\n':
                break
            line_objects = lines[i].split()
            matrix = [round(float(x), 1) for x in line_objects]     # 保留一位小数
            matrix_objects.append(matrix)
        solutions = []
        for i in range(len(matrix_objects)):
            solution = []
            solutions.append(solution)
        flag = 0
        nu_flag = 0
        solu = []
        for line in lines:          # 读取解
            if flag < 2+len(matrix_objects):
                flag += 1
            elif line == '\n':
                solutions[nu_flag] = solu
                solu=[]
                nu_flag += 1
                if nu_flag == len(matrix_objects):
                    break
                flag += 1
            else:
                line_split = line.split()
                solu.append([float(x) for x in line_split])
                flag += 1
        for f in range(len(solutions)):
            image_name = f'layers_{lays}_solution_{f}'
            fig, gnt = plt.subplots()   # 创建画布
            plt.title(f'{int(matrix_ins_info[0])}j_{int(matrix_ins_info[1])}m_{lays}l_{f}s_ob{matrix_objects[f]}')
            fig.set_size_inches(20, 5)
            num_machines = matrix_ins_info[1]
            machines = []
            for m in range(matrix_ins_info[1]):
                machines.append(str(f'M{m}'))
            gnt.set_xlim(0, 240, 24)            # x轴范围
            gnt.set_ylim(0, num_machines)       # y轴范围
            x_ticks = []
            for x in range((240 // 24)+1):
                x_ticks.append(x * 24)
                x_ticks.append(x * 24 + 8)
                x_ticks.append(x * 24 + 12)
            gnt.set_xticks(x_ticks)             # 设置x轴
            gnt.set_xticklabels(x_ticks, fontsize='10')     # x轴标签
            gnt.set_yticks([i + 0.5 for i in range(num_machines)])
            gnt.set_yticklabels(machines, fontsize='16', color='r')
            gnt.set_xlabel('Time (hours)')
            gnt.set_ylabel('Machine')
            # 设置24小时的背景色
            for i in range(240//24):
                plt.plot([i * 24 + 8, i * 24 + 8], [0, num_machines], linestyle='--', color='y')    # plt.plot([s_x, e_x], [s_y, e_y])
                plt.plot([i * 24 + 12, i * 24 + 12], [0, num_machines], linestyle='--', color='r')
                plt.plot([i * 24 + 24, i * 24 + 24], [0, num_machines], linestyle='-', color='r')
                gnt.fill_between([i * 24 + 8, i * 24 + 12], 0, num_machines, hatch=("/ /"), color='y', facecolor='w', alpha=0.5)    # gnt.fill_between([s_x, e_x], s_y, e_y,)
                gnt.fill_between([i * 24 + 12, i * 24 + 24], 0, num_machines, hatch=("/ /"), color='r', facecolor='w', alpha=0.8)
            # 绘制工序
            #colors = ['b', 'g', 'r', 'c', 'm', 'y']
            #colors = []
            #for i in range(matrix_ins_info[0]):
                #colors.append('#{:06x}'.format(random.randint(0, 0xFFFFFF)))
            colors = select_colors(int(matrix_ins_info[0]))
            for i in range(len(solutions[f])):
                machina_index = solutions[f][i][0:matrix_ins_info[1]].index(1)      # 机床
                job_index = solutions[f][i][-6]+1                                   # job
                opes_index = solutions[f][i][-4]                                    # opes
                proc_time, start_time, end_time = solutions[f][i][-3:]              # pro_t, sta_t, end_t
                if start_time//24 == end_time//24:  # 开始结束在同一天
                    gnt.broken_barh([(start_time, proc_time)], (machina_index+0.25, 0.5), facecolors=colors[int(job_index % len(colors))], edgecolors='k')
                else:
                    start_day, end_day = int(start_time//24), int(end_time//24)   # 开始、结束的天数
                    gnt.broken_barh([(start_time, start_day*24+8-start_time)], (machina_index + 0.25, 0.5), facecolors=colors[int(job_index % len(colors))], edgecolors='k')
                    for d in range(start_day+1, end_day):
                        gnt.broken_barh([(d*24, 8)], (machina_index + 0.25, 0.5), facecolors=colors[int(job_index % len(colors))], edgecolors='k')
                    gnt.broken_barh([(end_day*24, end_time-end_day*24)], (machina_index + 0.25, 0.5),facecolors=colors[int(job_index % len(colors))], edgecolors='k')
                #plt.plot([end_time, end_time], [machina_index+0.25, machina_index+0.75], linestyle='-', color='r')  # 结束为一条红线
                plt.plot([start_time, start_time], [machina_index + 0.25, machina_index + 0.75], linestyle='--',color='black')  # 开始为一条黑线
                plt.text(start_time+0.5, machina_index+0.5, f'J{int(job_index)}\nO{int(opes_index)}\nP{int(proc_time)}', va='center',fontdict={'family': 'Arial', 'size': 12, 'color': 'black'})
            # 保存甘特图
            save_path = file_path + '/gantt'
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            plt.savefig(save_path + f'/{image_name}.png')
            #plt.show()

if __name__ == '__main__':
    main()







