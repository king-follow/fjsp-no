import copy
import math
import torch
import random
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
from graph.hgnn import GATedge, MLPsim, MultiLSTMMergeAttention, GATModel, SATModel
from mlp import MLPCritic, MLPActor, MLPObjective
from torchinfo import summary
#import MON_model

class Memory:
    def __init__(self):
        self.states = []
        self.logprobs = []
        self.logprobs_used = []
        self.rewards = []
        self.is_terminals = []
        self.action_indexes = []
        self.action_jobs = []

        self.ope_ma_adj = []
        self.unope_ma_adj = []
        self.ope_pre_adj = []
        self.ope_sub_adj = []
        self.batch_idxes = []
        self.raw_opes = []
        self.raw_mas = []
        self.raw_useds = []
        self.raw_total = []
        self.proc_time = []
        self.jobs_gather = []
        self.eligible = []
        self.nums_opes = []
        self.opes_adj = []
        self.gat_opes_adj = []

    def clear_memory(self):
        del self.states[:]
        del self.logprobs[:]
        del self.logprobs_used[:]
        del self.rewards[:]
        del self.is_terminals[:]
        del self.action_indexes[:]
        del self.action_jobs[:]

        del self.ope_ma_adj[:]
        del self.ope_pre_adj[:]
        del self.ope_sub_adj[:]
        del self.batch_idxes[:]
        del self.raw_opes[:]
        del self.raw_mas[:]
        del self.raw_useds[:]
        del self.raw_total[:]
        del self.proc_time[:]
        del self.jobs_gather[:]
        del self.eligible[:]
        del self.nums_opes[:]
        del self.opes_adj[:]
        del self.gat_opes_adj[:]

class MLPs(nn.Module):
    '''
    MLPs in operation node embedding
    '''
    def __init__(self,input_dim, hidden_dim, output_dim):
        '''
        The multi-head and dropout mechanisms are not actually used in the final experiment.
        :param W_sizes_ope: A list of the dimension of input vector for each type,
        including [machine, operation (pre), operation (sub), operation (self)]
        :param hidden_size_ope: hidden dimensions of the MLPs
        :param out_size_ope: dimension of the embedding of operation nodes
        '''
        super(MLPs, self).__init__()
        self.em_in_ope_dim = input_dim[0]
        self.em_in_mas_dim = input_dim[1]
        self.em_in_tol_dim = input_dim[2]
        self.em_out_dim = output_dim
        self.em_hid_dim = hidden_dim
        #self.ops_list = nn.ModuleList()         # 包含三个对opes处理
        # 对于opes 采用三个全连接层 最后由一个全连接， 13，14，16
        #for i in range(1,len(self.in_sizes_ope)):
            #self.ops_list.append(MLPsim(self.in_sizes_ope[i], self.out_size_ope, self.hidden_size_ope, self.num_head, self.dropout, self.dropout))
        # 最后的汇总处理ops、mas
        self.project_ops = nn.Sequential(
            nn.ELU(),
            nn.Linear(self.em_in_ope_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_out_dim),
            nn.ELU(),)
        self.project_mas = nn.Sequential(
            nn.ELU(),
            nn.Linear(self.em_in_mas_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_out_dim),
            nn.ELU(),)
        self.project_tol = nn.Sequential(
            nn.ELU(),
            nn.Linear(self.em_in_tol_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_hid_dim),
            nn.ELU(),
            nn.Linear(self.em_hid_dim, self.em_out_dim),
            nn.ELU(),)

    def forward(self, feats, ope_ma_adj_batch, norm_opes_adj):
        '''
        :param ope_ma_adj_batch: Adjacency matrix of operation and machine nodes
        :param ope_pre_adj_batch: Adjacency matrix of operation and pre-operation nodes
        :param ope_sub_adj_batch: Adjacency matrix of operation and sub-operation nodes
        :param batch_idxes: Uncompleted instances
        :param feats: Contains operation, machine and edge features
        '''
        a_ope = feats[0]     # 2,31,128
        a_mas = feats[1]     # 2,4,128
        a_tol = feats[2]
        norm_opes_adj = norm_opes_adj.transpose(1,2)
        # 特征与位置之间的关系，嵌入位置的关系，并把机器节点嵌入到工序节点
        em_mas = torch.sum(ope_ma_adj_batch.unsqueeze(-1)*(a_mas.unsqueeze(1)), dim=1) # [2, 3, 128]
        em_mas2ope = torch.sum(ope_ma_adj_batch.unsqueeze(-1)*(a_mas.unsqueeze(1)), dim=-2)
        em_ope = torch.sum(norm_opes_adj.unsqueeze(-1)*(a_ope.unsqueeze(1)), dim=1)
        em_in_ope = torch.cat((em_ope, em_mas2ope), dim=-1)
        h_opes = self.project_ops(em_in_ope)
        h_mas = self.project_mas(em_mas)
        h_tol = self.project_tol(a_tol)
        return h_opes, h_mas, h_tol

class HGNNScheduler(nn.Module):
    def __init__(self, model_paras):
        super(HGNNScheduler, self).__init__()
        self.device = model_paras["device"]
        self.in_size_ope = model_paras["in_size_ope"]+model_paras["num_mas"]
        self.in_size_ma = model_paras["in_size_ma"]+model_paras["num_jobs"]    # 机器节点原始特征向量的维数
        self.in_size_used = model_paras["in_size_used"]
        self.mlp_out_dim = model_paras["mlp_out_dim"]

        self.gat_out_dim = self.mlp_out_dim
        self.gat_num_layers = model_paras["gat_num_layers"]
        self.sat_num_layers = model_paras["sat_num_layers"]

        self.em_hid_dim = model_paras["em_hid_dim"]
        self.em_in_ope_dim = self.gat_out_dim*2
        self.em_hid_num = model_paras["em_hid_num"]
        self.em_out_dim = model_paras["em_out_dim"]


        self.actor0_in_dim = self.em_out_dim*2
        self.actor0_out_dim = model_paras["actor0_out_dim"]
        self.actor0_hid_num = model_paras["actor0_hid_num"]
        self.actor0_hid_dim = model_paras["actor0_hid_dim"]

        self.critic0_in_dim = self.em_out_dim*3
        self.critic0_out_dim = model_paras["critic0_out_dim"]
        self.critic0_hid_num = model_paras["critic0_hid_num"]
        self.critic0_hid_dim = model_paras["critic0_hid_dim"]

        self.actor1_in_dim = self.em_out_dim
        self.actor1_out_dim = model_paras["actor1_out_dim"]
        self.actor1_hid_num = model_paras["actor1_hid_num"]
        self.actor1_hid_dim = model_paras["actor1_hid_dim"]

        self.critic1_in_dim = self.em_out_dim
        self.critic1_out_dim = model_paras["critic1_out_dim"]
        self.critic1_hid_num = model_paras["critic1_hid_num"]
        self.critic1_hid_dim = model_paras["critic1_hid_dim"]

        self.ob_in_dim = model_paras["ob_in_dim"]
        self.ob_out_dim = model_paras["ob_out_dim"]
        self.ob_hid_dim = model_paras["ob_hid_dim"]
        self.ob_hid_num = model_paras["ob_hid_num"]


        # len() means of the number of HGNN iterations
        # and the element means the number of heads of each HGNN (=1 in final experiment)
        self.num_heads = model_paras["num_heads"]
        self.dropout = model_paras["dropout"]

        self.policy_gnn = nn.ModuleList()  # 装 HGNN、actor、critic
        self.policy_actor = nn.ModuleList()  # 装 used_actor、used_critic
        self.policy_critic = nn.ModuleList()

        get_gat = nn.ModuleList()
        get_sat = nn.ModuleList()
        get_em = nn.ModuleList()

        get_gat.append(GATModel((self.in_size_ope, self.in_size_ma), self.mlp_out_dim, self.gat_out_dim, self.gat_num_layers, self.num_heads[0]))
        for i in range(1, len(self.num_heads)):
            get_gat.append(GATModel((self.in_size_ope, self.in_size_ma), self.mlp_out_dim, self.gat_out_dim, self.gat_num_layers,self.num_heads[i]))
        self.policy_gnn.append(get_gat)

        get_sat.append(SATModel(self.in_size_used, self.mlp_out_dim, self.gat_out_dim, self.sat_num_layers, self.num_heads[0]))
        for i in range(1, len(self.num_heads)):
            get_sat.append(SATModel(self.in_size_used, self.mlp_out_dim, self.gat_out_dim, self.sat_num_layers, self.num_heads[i]))
        self.policy_gnn.append(get_sat)

        get_em.append(MLPs([self.em_in_ope_dim, self.gat_out_dim, self.gat_out_dim], self.em_hid_dim, self.em_out_dim))
        for i in range(len(self.num_heads) - 1):
            get_em.append(MLPs([self.em_in_ope_dim, self.gat_out_dim, self.gat_out_dim], self.em_hid_dim, self.em_out_dim))
        self.policy_gnn.append(get_em)

        self.policy_gnn.append(MLPObjective(self.ob_hid_num, self.ob_in_dim, self.ob_hid_dim, self.ob_out_dim).to(self.device))

        self.policy_actor.append(MLPActor(self.actor0_hid_num, self.actor0_in_dim, self.actor0_hid_dim, self.actor0_out_dim).to(self.device))
        self.policy_critic.append(MLPCritic(self.critic0_hid_num, self.critic0_in_dim, self.critic0_hid_dim, self.critic0_out_dim).to(self.device))

        self.policy_actor.append(MLPActor(self.actor1_hid_num, self.actor1_in_dim, self.actor1_hid_dim, self.actor1_out_dim).to(self.device))
        self.policy_critic.append(MLPCritic(self.critic1_hid_num, self.critic1_in_dim, self.critic1_hid_dim, self.critic1_out_dim).to(self.device))

    def forward(self):
        '''
        Replaced by separate act and evaluate functions
        '''
        raise NotImplementedError
    def feature_normalize(self, data):
        non_zero_data = data[data != 0]
        mean = non_zero_data.mean()
        std = non_zero_data.std()
        # 标准化数据并保留零值为零
        normalized_data = data.clone()
        normalized_data[data != 0] = (data[data != 0] - mean) / (std + 1e-5)
        return normalized_data
    '''
        raw_opes: shape: [len(batch_idxes), max(num_opes), in_size_ope]
        raw_mas: shape: [len(batch_idxes), num_mas, in_size_ma]
        proc_time: shape: [len(batch_idxes), max(num_opes), num_mas]
    '''
    def get_normalized(self, raw_opes, raw_mas, raw_useds, raw_opes_adj, proc_time, raw_gat_opes_adj_batch, batch_idxes):

        r_ws = copy.deepcopy(raw_useds)
        # 每个实例可能有不同的操作，这些操作不能直接由矩阵规范化,There may be different operations for each instance, which cannot be normalized directly by the matrix
        mean_opes = torch.mean(raw_opes, dim=-2, keepdim=True)  # shape: [len(batch_idxes), 1, in_size_ope],-2:行
        mean_mas = torch.mean(raw_mas, dim=-2, keepdim=True)  # shape: [len(batch_idxes), 1, in_size_ma]
        mean_useds = torch.mean(raw_useds[batch_idxes, :-3], dim=-1, keepdim=True) # shape: [len(batch_idxes), 1]
        std_opes = torch.std(raw_opes, dim=-2, keepdim=True)  # shape: [len(batch_idxes), 1, in_size_ope]
        std_mas = torch.std(raw_mas, dim=-2, keepdim=True)  # shape: [len(batch_idxes), 1, in_size_ma]
        std_useds = torch.std(raw_useds[batch_idxes, :-3], dim=-1, keepdim=True) # shape: []
        proc_time_norm = self.feature_normalize(proc_time)  # shape: [len(batch_idxes), num_opes, num_mas]
        raw_gat_opes_adj_norm = self.feature_normalize(raw_gat_opes_adj_batch)
        raw_o = raw_opes_adj.exp()
        nor_opes_adj = (raw_o - torch.mean(raw_o)) / ((raw_o.std() + 1e-5))
        r_ws[batch_idxes, :-3] = (raw_useds[batch_idxes, :-3] - mean_useds) / (std_useds + 1e-5)
        return ((raw_opes - mean_opes) / (std_opes + 1e-5), (raw_mas - mean_mas) / (std_mas + 1e-5),
                (r_ws).unsqueeze(1), proc_time_norm, nor_opes_adj, raw_gat_opes_adj_norm)

    def get_action_prob(self, state, memories, flag_sample=False, flag_train=False):
        '''
        Get the probability of selecting each action in decision-making
        '''
        # Uncompleted instances
        batch_idxes = state.batch_idxes
        # Raw feats
        raw_opes = state.feat_opes_batch.transpose(1, 2)[batch_idxes]   # operations_feat,transpose 转置
        raw_mas = state.feat_mas_batch.transpose(1, 2)[batch_idxes]     # machines_feat
        raw_objective = state.feat_used_batch[batch_idxes, :-3]
        raw_useds = state.feat_used_batch[batch_idxes]
        proc_time = state.proc_times_batch[batch_idxes]                 # 加工时间
        raw_opes_adj = state.opes_adj_batch[batch_idxes]
        raw_gat_opes_adj_batch = state.gat_opes_adj_batch[batch_idxes]

        # 计算目标参数：α β γ
        objective_batch = self.policy_gnn[3](raw_objective)
        raw_useds[batch_idxes, -3:] = F.softmax(objective_batch, dim=1)

        # Normalize, raw_useds的后三维是参数，不参与运算
        nums_opes = state.nums_opes_batch[batch_idxes]
        features = self.get_normalized(raw_opes, raw_mas, raw_useds, raw_opes_adj, proc_time, raw_gat_opes_adj_batch, batch_idxes)
        norm_opes = (copy.deepcopy(features[0]))        # ope_feats
        norm_mas = (copy.deepcopy(features[1]))         # mas_feats
        norm_proc = (copy.deepcopy(features[3]))        # proc_time_feats
        norm_useds = (copy.deepcopy(features[2]))       # tol_feats
        norm_opes_adj = (copy.deepcopy(features[4]))        # E
        norm_gat_opes_adj = (copy.deepcopy(features[5]))    # A
        feats = [norm_opes, norm_mas]
        adjs = [norm_gat_opes_adj, norm_proc]

        # L iterations of the HGNN
        for i in range(len(self.num_heads)):
            # First Stage, 注意力机制的计算
            out_opes, out_mas = self.policy_gnn[0][i](feats, adjs)
            out_tol = self.policy_gnn[1][i](norm_useds)
            out_feats = [out_opes, out_mas, out_tol]
            # Second Stage, operation\machines embedding
            h_opes, h_mas, h_tol = self.policy_gnn[2][i](out_feats, state.ope_ma_adj_batch, norm_opes_adj)    # h_opes:Size([2, 28, 16])、h_mas:Size([2, 4, 16])
        h_tol_pool = h_tol.mean(-2)      # 2,16

        # Stacking and pooling
        h_mas_pooled = h_mas.mean(dim=-2)  # Size([4, 8]),机床上数据相加 shape: [len(batch_idxes), out_size_ma]
        # There may be different operations for each instance, which cannot be pooled directly by the matrix 每个实例可能有不同的操作，这些操作不能直接由矩阵合并
        if not flag_sample and not flag_train:
            h_opes_pooled = []
            for i in range(len(batch_idxes)):
                h_opes_pooled.append(torch.mean(h_opes[i, :nums_opes[i], :], dim=-2))
            h_opes_pooled = torch.stack(h_opes_pooled)  # shape: [len(batch_idxes), d]
        else:
            h_opes_pooled = h_opes.mean(dim=-2)  # Size([4, 8]) shape: [len(batch_idxes), out_size_ope]

        # 检测符合条件的O-M对(符合条件的动作)并生成张量用于actor计算,Detect eligible O-M pairs (eligible actions) and generate tensors for actor calculation
        ope_step_batch = torch.where(state.ope_step_batch > state.end_ope_biases_batch, state.end_ope_biases_batch, state.ope_step_batch) # state.ope_step_batch
        jobs_gather = ope_step_batch[..., :, None].expand(-1, -1, h_opes.size(-1))[batch_idxes]    # Size([4, 10, 8])
        h_jobs = h_opes.gather(1, jobs_gather)# Size([4, 10, 8]),根据jobs_gather的顺序，拿出每个job的首operation
        # shape: [len(batch_idxes), num_jobs, num_mas]
        eligible_proc = state.ope_ma_adj_batch[batch_idxes].gather(1, ope_step_batch[..., :, None].expand(-1, -1, state.ope_ma_adj_batch.size(-1))[batch_idxes]) # Size([4, 10, 5])
        h_jobs_padding = h_jobs.unsqueeze(-2).expand(-1, -1, state.proc_times_batch.size(-1), -1)# Size([4, 10, 5, 8]),h_jobs.unsqueeze(-2)=Size([4, 10, 1, 8])
        h_mas_padding = h_mas.unsqueeze(-3).expand_as(h_jobs_padding)# Size([4, 10, 5, 8]),h_mas.unsqueeze(-3)=torch.Size([4, 1, 5, 8])

        # shape: [len(batch_idxes), num_jobs, num_mas]
        ma_eligible = ~state.mask_ma_procing_batch[batch_idxes].unsqueeze(1).expand_as(h_jobs_padding[..., 0])# Size([4, 10, 5]),全为Ture
        # Matrix indicating whether job is eligible
        # shape: [len(batch_idxes), num_jobs, num_mas]
        job_eligible = ~(state.mask_job_procing_batch[batch_idxes] + state.mask_job_finish_batch[batch_idxes])[:, :, None].expand_as(h_jobs_padding[..., 0])# Size([4, 10, 5])
        # shape: [len(batch_idxes), num_jobs, num_mas]
        eligible = job_eligible & ma_eligible & (eligible_proc == 1)    # Size([4, 10, 5])

        if (~(eligible)).all():
            print("No eligible O-M pair!")
            return
        # Input of actor MLP
        # shape: [len(batch_idxes), num_mas, num_jobs, out_size_ma*2+out_size_ope*2]
        h_actions = torch.cat((h_jobs_padding, h_mas_padding), dim=-1).transpose(1, 2)# Size([4, 5, 10, 32])
        h_pooled = torch.cat((h_opes_pooled, h_mas_pooled, h_tol_pool), dim=-1)  # Size([1, 16])deprecated
        mask = eligible.transpose(1, 2).flatten(1)  #Size([4, 50]), eligible.transpose(转置)(1, 2)=Size([4, 5, 10])

        # Get priority index and probability of actions with masking the ineligible actions,通过屏蔽不符合条件的操作，得到操作的优先级索引和操作的概率
        ori_shape = eligible.transpose(1, 2).shape
        scores = self.policy_actor[0](h_actions).flatten(1)
        scores[~mask] = float('-inf')#  Size([4, 50])
        action_probs = (F.softmax(scores, dim=1)).view(ori_shape)

        # job策略选择
        scores_selects = self.policy_actor[1](h_tol.squeeze(1))
        action_selects = F.softmax(scores_selects, dim=1)

        # 保存,objective
        objective = copy.deepcopy(raw_useds[batch_idxes, -3:])

        # Store data in memory during training
        if flag_train == True:
            memories.ope_ma_adj.append(copy.deepcopy(state.ope_ma_adj_batch))
            memories.ope_pre_adj.append(copy.deepcopy(state.ope_pre_adj_batch))
            memories.ope_sub_adj.append(copy.deepcopy(state.ope_sub_adj_batch))
            memories.batch_idxes.append(copy.deepcopy(state.batch_idxes))
            memories.raw_opes.append(copy.deepcopy(norm_opes))
            memories.raw_mas.append(copy.deepcopy(norm_mas))
            memories.raw_useds.append(copy.deepcopy(norm_useds))
            memories.raw_total.append(copy.deepcopy(raw_useds))
            memories.opes_adj.append(copy.deepcopy(norm_opes_adj))
            memories.proc_time.append(copy.deepcopy(norm_proc))
            memories.nums_opes.append(copy.deepcopy(nums_opes))
            memories.jobs_gather.append(copy.deepcopy(jobs_gather))
            memories.eligible.append(copy.deepcopy(eligible))
            memories.gat_opes_adj.append(copy.deepcopy(norm_gat_opes_adj))
        return action_probs.transpose(1,2), action_selects, ope_step_batch, eligible, objective, h_pooled

    def select_jobs(self, state, eligible, action_select_jobs):
        batch_idxes = state.batch_idxes
        select_job = torch.zeros(len(state.batch_idxes))
        action_eligible = eligible

        eligible = torch.all(action_eligible == False, dim=2)
        tar_opes_batch = copy.deepcopy(state.tar_opes_batch)
        for batch in batch_idxes:
            tar_opes = tar_opes_batch[batch]                              # 延迟的工序
            est_tar_job = torch.zeros(len(state.ope_step_batch[batch]))
            for j, star, end in zip(range(len(state.ope_step_batch[batch])), state.ope_step_batch[batch], state.end_ope_biases_batch[batch]):
                if star > end:          # 已完工
                    est_tar_job[j] = 0
                else:                   # 未完工
                    est_tar_job[j] = torch.sum(tar_opes[star:end+1])
            #est_tar_job = torch.tensor([torch.sum(tar_opes[sta:end+1]) for sta, end in zip(state.ope_step_batch[batch], state.end_ope_biases_batch[batch])])
            select = action_select_jobs[batch]                                   # 选择
            select_eligible = eligible[batch]                                    # 可用为False, 不可用为True
            op_uncom_num = state.op_uncom_batch[batch]                           # 未完成的工序数
            op_com_num = state.op_com_batch[batch]                               # 完工的工序数
            ma_time_avr = state.ma_time_batch[batch].mean()                      # 机床平均时间
            la_op_time = state.la_op_com_T_batch[batch]                          # 上一个已经完成工序得时间
            jobs_due_time = copy.deepcopy(state.job_due_time_batch[batch])       # job due time
            opes_end_time = copy.deepcopy(state.opes_end_times_batch[batch])     # opes end times
            jobs_end_time = opes_end_time.gather(0, state.end_ope_biases_batch[batch])     # jobs end times
            opes_proc_time_avr = copy.deepcopy(state.proc_times_avr_batch[batch])          # 未加工工序的平均时间
            if select == 0:
                if torch.sum(est_tar_job) == 0:     # ETJ == null, 未完工job: 剩余时间：少 / 未加工工序：多
                    time = torch.where(la_op_time > ma_time_avr, la_op_time, ma_time_avr)
                    t = (jobs_due_time - time).div(op_uncom_num)
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmin()]
                    select_job[batch] = job_index
                else:                               # 延迟job: 延期时间：多
                    t = jobs_end_time - jobs_due_time
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmax()]
                    select_job[batch] = job_index
            elif select == 1:                       # ETJ == null, 未完工job: 剩余时间：少 / 未加工工序时间总和：多
                if torch.sum(est_tar_job) == 0:
                    uncom_proc_time = torch.tensor([torch.sum(opes_proc_time_avr[sta:end+1]) for sta, end in zip(state.ope_step_batch[batch], state.end_ope_biases_batch[batch])])
                    time = torch.where(la_op_time > ma_time_avr, la_op_time, ma_time_avr)
                    t = (jobs_due_time - time).div(uncom_proc_time)
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmin()]
                    select_job[batch] = job_index
                else:                               # 延迟job: 延期时间：多
                    t = jobs_end_time - jobs_due_time
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmax()]
                    select_job[batch] = job_index
            elif select == 2:                       # 都提前在due_time 之前完成，未完工job：剩余时间：少
                if ((jobs_end_time - jobs_due_time) < 0).all():
                    t = jobs_end_time - jobs_due_time
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmax()]
                    select_job[batch] = job_index
                else:                               # 未完工job：延期时间：多
                    t = jobs_end_time - jobs_due_time
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmax()]
                    select_job[batch] = job_index
            elif select == 3:                       # ETJ == null, 未完工job: 完工工序：少 / 总工序：多， 剩余时间：少
                if torch.sum(est_tar_job) == 0:
                    time = torch.where(la_op_time > ma_time_avr, la_op_time, ma_time_avr)
                    t = op_com_num.div(op_uncom_num + op_com_num) * (jobs_due_time - time)
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmin()]
                    select_job[batch] = job_index
                else:                               # 总共序：多 / 完工工序：少 * 延迟时间：多
                    t = (op_uncom_num + op_com_num).div(op_com_num) * (jobs_end_time - jobs_due_time)
                    t[select_eligible] = float('nan')
                    valid_indices = torch.where(~torch.isnan(t))[0]
                    job_index = valid_indices[t[valid_indices].argmax()]
                    select_job[batch] = job_index
            elif select == 4:                       # 随机选择一个job
                t = ~select_eligible
                valid_indices = torch.where(t)[0]
                job_index = random.choice(valid_indices)
                select_job[batch] = job_index
        return select_job

    def act(self, state, memories, flag_sample=True, flag_train=True, flage_sample_rule=1):


        # Get probability of actions and the id of the current operation (be waiting to be processed) of each job
        action_probs, action_selects, ope_step_batch, action_eligible, objective, _ = self.get_action_prob(state, memories, flag_sample, flag_train=flag_train)

        dist = Categorical(action_probs.flatten(1))
        if flage_sample_rule == 1:            # 规则选择
            select_job_dist = Categorical(action_selects)           # dist
            action_select_jobs = select_job_dist.sample()           # 随机选择规则
            jobs = (self.select_jobs(state, action_eligible, action_select_jobs)).long()

            # 找出对应的机器
            machines_select = (action_probs.gather(1, jobs.unsqueeze(1).unsqueeze(1).expand(-1, -1, action_probs.shape[-1]))).squeeze(-2)

            machines_dist = Categorical(machines_select)
            mas = machines_dist.sample()
            opes = ope_step_batch[state.batch_idxes, jobs]
            index = jobs*action_probs.size(2)+mas

        # 在训练期间将数据存储在内存中Store data in memory during training
        if flag_train == True:
            # memories.states.append(copy.deepcopy(state))
            memories.logprobs.append(dist.log_prob(index)) # log_prob（某些动作的）概率的对数,返回密度或概率的对数，dist.log_prob(x)用来计算输入数据x在dist分布中的对于概率密度的对数
            memories.action_indexes.append(index)
            if flage_sample_rule == 1:
                memories.logprobs_used.append(select_job_dist.log_prob(action_select_jobs))
                memories.action_jobs.append(action_select_jobs)
        return torch.stack((opes, mas, jobs), dim=1).t(), objective

    def evaluate(self, ope_ma_adj, raw_opes, raw_mas, raw_useds, opes_adj, gat_opes_adj, proc_time,
                 jobs_gather, eligible, action_envs, action_jobs_envs):
        batch_idxes = torch.arange(0, ope_ma_adj.size(-3)).long()

        feats = [raw_opes, raw_mas]
        adjs = [gat_opes_adj, proc_time]

        # L iterations of the HGNN
        for i in range(len(self.num_heads)):
            # First Stage, 注意力机制的计算
            out_opes, out_mas = self.policy_gnn[0][i](feats, adjs)
            out_tol = self.policy_gnn[1][i](raw_useds)
            out_feats = [out_opes, out_mas, out_tol]
            # Second Stage, operation\machines embedding
            h_opes, h_mas, h_tol = self.policy_gnn[2][i](out_feats, ope_ma_adj, opes_adj)  # h_opes:Size([2, 28, 16])、h_mas:Size([2, 4, 16])
        # Stacking and pooling
        h_mas_pooled = h_mas.mean(dim=-2)
        h_opes_pooled = h_opes.mean(dim=-2)
        h_tol_pool = h_tol.mean(dim=-2)

        # 检测符合条件的O-M对(符合条件的动作)并生成张量进行临界计算，Detect eligible O-M pairs (eligible actions) and generate tensors for critic calculation
        h_jobs = h_opes.gather(1, jobs_gather)  # Size([30, 6, 8])
        h_jobs_padding = h_jobs.unsqueeze(-2).expand(-1, -1, proc_time.size(-1), -1)
        h_mas_padding = h_mas.unsqueeze(-3).expand_as(h_jobs_padding)
        #h_mas_pooled_padding = h_mas_pooled[:, None, None, :].expand_as(h_jobs_padding)
        #h_opes_pooled_padding = h_opes_pooled[:, None, None, :].expand_as(h_jobs_padding)
        #h_tol_pooled_padding = h_tol_pool[:, None, None, :].expand_as(h_jobs_padding)

        h_actions = torch.cat((h_jobs_padding, h_mas_padding), dim=-1).transpose(1, 2)  # Size([4, 5, 10, 32])
        h_pooled = torch.cat((h_opes_pooled, h_mas_pooled, h_tol_pool), dim=-1)  # Size([1, 16])deprecated

        # Get priority index and probability of actions with masking the ineligible actions,通过屏蔽不符合条件的操作，得到操作的优先级索引和操作的概率
        mask = eligible.transpose(1, 2).flatten(1)  # Size([4, 50]), eligible.transpose(转置)(1, 2)=Size([4, 5, 10])

        ori_shape = eligible.transpose(1, 2).shape
        scores = self.policy_actor[0](h_actions).flatten(1)
        scores[~mask] = float(-1e6)  # Size([4, 50])
        action_probs = (F.softmax(scores, dim=1)).view(ori_shape)
        state_values = self.policy_critic[0](h_pooled)

        # job策略选择
        scores_selects = self.policy_actor[1](h_tol.squeeze(1))
        action_selects = F.softmax(scores_selects, dim=1)
        state_selects_values = self.policy_critic[1](h_tol.squeeze(1))

        dist = Categorical((action_probs.transpose(1, 2)).flatten(1))
        action_logprobs = dist.log_prob(action_envs)  # 当前的action 相对于下一状态输出的Action的概率取对数
        dist_selects = Categorical(action_selects.squeeze())
        action_selects_logprobs = dist_selects.log_prob(action_jobs_envs)

        dist_entropys = dist.entropy()
        dist_selects_entropys = dist_selects.entropy()
        return action_logprobs, action_selects_logprobs, state_values.squeeze().double(), state_selects_values.squeeze().double(), dist_entropys, dist_selects_entropys

class PPO:
    def __init__(self, model_paras, train_paras, num_envs=None):
        self.lr = train_paras["lr"]         # 学习率learning rate
        self.betas = train_paras["betas"]   # Adam的默认值default value for Adam
        self.gamma = train_paras["gamma"]   # 折现系数discount factor
        self.eps_clip = train_paras["eps_clip"]  # 削波比PPO夹比clip ratio for PPO
        self.K_epochs = train_paras["K_epochs"]  # 更新K个epoch的策略Update policy for K epochs
        self.A_coeff = train_paras["A_coeff"]  # 保单损失系数coefficient for policy loss
        self.vf_coeff = train_paras["vf_coeff"]  # 价值损失系数coefficient for value loss
        self.entropy_coeff = train_paras["entropy_coeff"]  # 熵项系数coefficient for entropy term
        self.num_envs = num_envs  # 并行实例的数量Number of parallel instances
        self.device = model_paras["device"]  # PyTorch设备PyTorch device

        #self.policy = MON_model.MON(model_paras).to(self.device)
        self.policy = HGNNScheduler(model_paras).to(self.device)
        self.policy_old = copy.deepcopy(self.policy)
        self.policy_old.load_state_dict(self.policy.state_dict())
        self.optimizer_lstm_mlp = torch.optim.Adam(self.policy.policy_gnn.parameters(), lr=self.lr, betas=self.betas)
        self.optimizer_actor0 = torch.optim.Adam(self.policy.policy_actor[0].parameters(), lr=self.lr, betas=self.betas)
        self.optimizer_actor1 = torch.optim.Adam(self.policy.policy_actor[1].parameters(), lr=self.lr, betas=self.betas)
        self.optimizer_critic0 = torch.optim.Adam(self.policy.policy_critic[0].parameters(), lr=self.lr, betas=self.betas)
        self.optimizer_critic1 = torch.optim.Adam(self.policy.policy_critic[1].parameters(), lr=self.lr, betas=self.betas)
        self.MseLoss = nn.MSELoss()

    def update(self, memory, env_paras, train_paras):
        device = env_paras["device"]
        minibatch_size = train_paras["minibatch_size"]  # batch size for updating

        # 平摊内存中的数据(在并行实例和决策点的阴影中)Flatten the data in memory (in the dim of parallel instances and decision points)
        old_ope_ma_adj = torch.stack(memory.ope_ma_adj, dim=0).transpose(0,1).flatten(0,1)  # Size([28, 14, 3])工序对机床的选择(每个矩阵是一次机床的选择)，按算例、工序排列

        old_raw_opes = torch.stack(memory.raw_opes, dim=0).transpose(0, 1).flatten(0, 1)        # Size([28, 14, 6])
        old_raw_mas = torch.stack(memory.raw_mas, dim=0).transpose(0, 1).flatten(0, 1)          # Size([28, 3, 3])
        old_raw_useds = torch.stack(memory.raw_useds, dim=0).transpose(0, 1).flatten(0, 1)      # raw_useds

        old_opes_adj = torch.stack(memory.opes_adj, dim=0).transpose(0, 1).flatten(0, 1)        # opes_adj
        old_gat_opes_adj = torch.stack(memory.gat_opes_adj, dim=0).transpose(0, 1).flatten(0, 1)
        old_proc_time = torch.stack(memory.proc_time, dim=0).transpose(0, 1).flatten(0, 1)      # 归一化后的Size([28, 14, 3])
        old_jobs_gather = torch.stack(memory.jobs_gather, dim=0).transpose(0, 1).flatten(0, 1)  # Size([28, 6, 8])
        old_eligible = torch.stack(memory.eligible, dim=0).transpose(0, 1).flatten(0, 1)      # Size([28, 6, 3])
        memory_rewards = torch.stack(memory.rewards, dim=0).transpose(0,1)  # Size([2, 14])
        memory_is_terminals = torch.stack(memory.is_terminals, dim=0).transpose(0,1)            # Size([2, 14])
        old_logprobs = torch.stack(memory.logprobs, dim=0).transpose(0,1).flatten(0,1)          # Size([28])log_prob返回密度或概率的对数
        old_logprobs_used = torch.stack(memory.logprobs_used, dim=0).transpose(0,1).flatten(0,1)# 选择得概率在整个所有概率下得对数
        old_action_envs = torch.stack(memory.action_indexes, dim=0).transpose(0,1).flatten(0, 1)    # Size([28]),每次选择的工序
        old_action_jobs_envs = torch.stack(memory.action_jobs, dim=0).transpose(0, 1).flatten(0, 1)  # 选择得结果

        # 估算并规范奖励Estimate and normalize the rewards
        rewards_envs = []
        discounted_rewards = 0
        for i in range(self.num_envs):  # num_envs，就是算例个数，计算每个算例的奖励
            rewards = []
            discounted_reward = 0
            for reward, is_terminal in zip(reversed(memory_rewards[i]), reversed(memory_is_terminals[i])):  # reversed 倒过来处理，从尾到前取值计算
                if is_terminal:
                    discounted_rewards += discounted_reward
                    discounted_reward = 0
                discounted_reward = reward + (self.gamma * discounted_reward)   # 折现奖励 = 奖励 + (折现率 * 折现奖励)
                rewards.insert(0, discounted_reward)
            discounted_rewards += discounted_reward
            rewards = torch.tensor(rewards, dtype=torch.float64).to(device)
            rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-5)   # 奖励去均值,求期望
            rewards_envs.append(rewards)
        rewards_envs = torch.cat(rewards_envs)
        #  Adam Optimizer算法 ：https://zhuanlan.zhihu.com/p/268193140?utm_source=wechat_session
        loss_lstm_mlp_epochs = 0
        loss_actor0_epoch = 0
        loss_critic0_epoch = 0
        loss_actor1_epoch = 0
        loss_critic1_epoch = 0
        avg_all_loss = 0

        full_batch_size = old_ope_ma_adj.size(0)
        num_complete_minibatches = math.floor(full_batch_size / minibatch_size) # minibatch_size: 一堆里面有多少个数据； full_batch_size / minibatch_size: 分了几堆
        #优化K个epochs的策略 Optimize policy for K epochs:
        for _ in range(self.K_epochs):  # self.K_epochs = 3，一般深度学习训练过程会在外层再套一个循环来遍历多个epoch
            for i in range(num_complete_minibatches+1):
                if i < num_complete_minibatches:
                    start_idx = i * minibatch_size
                    end_idx = (i + 1) * minibatch_size
                else:
                    start_idx = i * minibatch_size
                    end_idx = full_batch_size
                logprobs, logprobs_selects, state_values, state_selects_values, dist_entropy, dist_selects_entropys= \
                    self.policy.evaluate(old_ope_ma_adj[start_idx: end_idx, :, :],
                                         old_raw_opes[start_idx: end_idx, :, :],
                                         old_raw_mas[start_idx: end_idx, :, :],
                                         old_raw_useds[start_idx: end_idx, :],
                                         old_opes_adj[start_idx: end_idx, :, :],
                                         old_gat_opes_adj[start_idx: end_idx, :, :],
                                         old_proc_time[start_idx: end_idx, :, :],
                                         old_jobs_gather[start_idx: end_idx, :, :],
                                         old_eligible[start_idx: end_idx, :, :],
                                         old_action_envs[start_idx: end_idx],
                                         old_action_jobs_envs[start_idx: end_idx])
                # 1\
                advantages = rewards_envs[start_idx: end_idx] - state_values.detach()
                advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
                ratios = torch.exp(logprobs - old_logprobs[start_idx: end_idx].detach())

                policy_loss_1 = ratios * advantages
                policy_loss_2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
                policy_loss = - self.A_coeff * torch.min(policy_loss_1, policy_loss_2).mean()
                value_loss = self.MseLoss(rewards_envs[start_idx: end_idx], state_values)
                entropy_loss = -torch.mean(-logprobs)

                loss_actor0 = policy_loss + self.entropy_coeff * entropy_loss + self.vf_coeff * value_loss
                loss_actor0_epoch += loss_actor0.mean().detach()

                loss_critic0 = value_loss
                loss_critic0_epoch += loss_critic0.mean().detach()

                # 2\
                advantages_used = rewards_envs[start_idx: end_idx] - state_selects_values.detach()
                advantages_used = (advantages_used - advantages_used.mean()) / (advantages_used.std() + 1e-8)
                ratios_used = torch.exp(logprobs_selects - old_logprobs_used[start_idx: end_idx].detach())

                p_l_1 = ratios_used * advantages_used
                p_l_2 = torch.clamp(ratios_used, 1 - self.eps_clip, 1 + self.eps_clip) * advantages_used
                policy_loss_used = - self.A_coeff * torch.min(p_l_1, p_l_2).mean()
                value_loss_used = self.MseLoss(rewards_envs[start_idx: end_idx], state_selects_values)
                entropy_loss_used = -torch.mean(-logprobs_selects)

                loss_actor1 = policy_loss_used + self.entropy_coeff * entropy_loss_used + self.vf_coeff * value_loss_used
                loss_actor1_epoch += loss_actor1.mean().detach()

                loss_critic1 = value_loss_used
                loss_critic1_epoch += loss_critic1.mean().detach()

                loss_lstm_mlp = loss_actor0
                loss_lstm_mlp_epochs += loss_lstm_mlp.mean().detach()

                # 在每个损失函数之前清零梯度
                self.optimizer_actor0.zero_grad()
                self.optimizer_critic0.zero_grad()
                self.optimizer_actor1.zero_grad()
                self.optimizer_critic1.zero_grad()
                self.optimizer_lstm_mlp.zero_grad()

                # 计算并反向传播损失函数
                loss_actor0.mean().backward(retain_graph=True)
                loss_critic0.backward(retain_graph=True)
                loss_actor1.mean().backward(retain_graph=True)
                loss_critic1.backward(retain_graph=True)
                loss_lstm_mlp.mean().backward()

                avg_all_loss += (loss_actor0 + loss_actor1).mean().detach()
                # 更新优化器
                self.optimizer_actor0.step()
                self.optimizer_critic0.step()
                self.optimizer_actor1.step()
                self.optimizer_critic1.step()
                self.optimizer_lstm_mlp.step()

            # 将新的权重复制到旧的策略中Copy new weights into old policy:
            self.policy_old.load_state_dict(self.policy.state_dict())  # 将新的权重更新到网络中
            reward_loss = [round(discounted_rewards.item() / (self.num_envs * train_paras["update_timestep"]), 3),
                           round(avg_all_loss.item() / self.K_epochs, 3),
                           round(loss_actor0_epoch.item() / self.K_epochs, 3),
                           round(loss_critic0_epoch.item() / self.K_epochs, 3),
                           round(loss_actor1_epoch.item() / self.K_epochs, 3),
                           round(loss_critic1_epoch.item() / self.K_epochs, 3),
                           round(loss_lstm_mlp_epochs.item() / self.K_epochs, 3)]
            return reward_loss
