import json
import random

class CaseMake:
    '''
    FJSP instance generator
    '''
    def __init__(self, job_init, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=None,
                 path='./data_un/804/', flag_same_opes=True, flag_doc=True):
        if nums_ope is None:
            nums_ope = []
        self.flag_doc = flag_doc  # Whether save the instance to a file
        self.flag_same_opes = flag_same_opes
        self.nums_ope = nums_ope
        self.path = path  # Instance save path (relative path)
        self.job_init = job_init
        self.num_mas = num_mas

        self.mas_per_ope_min = 1  # The minimum number of machines that can process an operation
        self.mas_per_ope_max = num_mas
        self.opes_per_job_min = opes_per_job_min  # The minimum number of operations for a job
        self.opes_per_job_max = opes_per_job_max
        self.proctime_per_ope_min = 1  # Minimum average processing time
        self.proctime_per_ope_max = 20
        self.proctime_unope_min = 1
        self.proctime_unope_max = 12
        self.proctime_dev = 0.2

    def get_case(self, idx=0):
        '''
        Generate FJSP instance
        :param idx: The instance number
        '''
        self.num_jobs = self.job_init
        if not self.flag_same_opes:
            self.nums_ope = [random.randint(self.opes_per_job_min, self.opes_per_job_max) for _ in range(self.num_jobs)]
        self.num_opes = sum(self.nums_ope)
        self.nums_option = [random.randint(self.mas_per_ope_min, self.mas_per_ope_max) for _ in range(self.num_opes)]   # 为每个工序分配可用的机床数
        self.num_options = sum(self.nums_option)
        self.ope_ma = []
        for val in self.nums_option:
            self.ope_ma = self.ope_ma + sorted(random.sample(range(1, self.num_mas+1), val))    # 分机床
        self.proc_time = []
        self.proc_times_mean = [random.randint(self.proctime_per_ope_min, self.proctime_per_ope_max) for _ in range(self.num_opes)]
        self.num_ope_biass = [sum(self.nums_ope[0:i]) for i in range(self.num_jobs)]
        self.num_ma_biass = [sum(self.nums_option[0:i]) for i in range(self.num_opes)]
        # 为每个job选择不可中断的工序（随机）
        self.un_opes = [random.randint(0, self.nums_ope[i] - 1) for i in range(self.num_jobs)]  # 0：无   其他：第几个工序数为不可中断工序
        self.num_unope_biass = [self.num_ope_biass[i] + self.un_opes[i] - 1 for i in range(self.num_jobs)]  # 记住对应的不可中断工序的id
        for j in range(len(self.num_ope_biass)):
            if self.num_unope_biass[j] < self.num_ope_biass[j]:     # 如果不可中断的id < job_star id, 说明此job没有不可中断工序，置为 -1
                self.num_unope_biass[j] = -1
        for i in range(len(self.nums_option)):
            if i in self.num_unope_biass:  # 为不可中断工序定义加工时间
                proc_time_mean = random.randint(self.proctime_unope_min, self.proctime_unope_max)           # 随机一个时间
                low_bound = max(self.proctime_unope_min, round(proc_time_mean * (1 - self.proctime_dev)))   # 下界时间
                high_bound = min(self.proctime_unope_max, round(proc_time_mean * (1 + self.proctime_dev)))  # 上界时间
                proc_time_ope = [random.randint(low_bound, high_bound) for _ in range(self.nums_option[i])]
                self.proc_time = self.proc_time + proc_time_ope              # 记录总时间
            else:  # 可中断时间定义`
                low_bound = max(self.proctime_per_ope_min, round(self.proc_times_mean[i] * (1 - self.proctime_dev)))
                high_bound = min(self.proctime_per_ope_max, round(self.proc_times_mean[i] * (1 + self.proctime_dev)))
                proc_time_ope = [random.randint(low_bound, high_bound) for _ in range(self.nums_option[i])]
                self.proc_time = self.proc_time + proc_time_ope              # 记录总时间
        # 计算每个job的最大完成时间，平均完成时间
        max_jobs_time = [0 for _ in range(self.num_jobs)]   # 最大完工时间
        mean_jobs_time = [0 for _ in range(self.num_jobs)]  # 平均完工时间
        n = 0
        for j,o in zip(range(self.num_jobs), self.nums_ope):  # job nums, job_opes nums
            for ma in self.nums_option[self.num_ope_biass[j]:self.num_ope_biass[j]+o]:      # 每个job的工序对应的机床数
                max_ope_time = max(self.proc_time[n:n+ma])      # 每个工序对应机床数找对应的时间 最大值
                mean_ope_time = round(sum(self.proc_time[n:n+ma])/ma, 1)    # 该工序的平均处理时间
                n = ma+n
                max_jobs_time[j] = max_jobs_time[j]+max_ope_time
                mean_jobs_time[j] = mean_jobs_time[j]+mean_ope_time
        amend_max_time = []
        amend_mean_time = []
        for d_max, d_mean in zip(max_jobs_time, mean_jobs_time):    # 对完成时间处理
            d_max = (d_max//8)*24 + d_max%8 if d_max%8>0 else ((d_max//8)-1)*24+8
            d_mean = (d_mean//8)*24 + d_mean%8 if d_mean%8>0 else ((d_mean//8)-1)*24+8
            amend_max_time.append(d_max)
            amend_mean_time.append(d_mean)
        # ave_amend_max_time = round(sum(amend_max_time)/self.num_jobs)
        due_time = [x+24*2 for x in amend_max_time]     # 定义due_time为最大时间+2天

        line0 = '{0}\t{1}\t{2}\n'.format(self.num_jobs, self.num_mas, self.num_options / self.num_opes)
        #lines = []
        lines_doc = []
        #lines.append(line0)
        lines_doc.append('{0}\t{1}\t{2}'.format(self.num_jobs, self.num_mas, self.num_options / self.num_opes)) # jobs、mas、operations
        str_line_un_opes = (" ".join([str(val) for val in self.un_opes]))
        lines_doc.append(str_line_un_opes)  # 不可终端的工序
        str_line_due_time = (" ".join([str(val) for val in due_time]))  # due time
        lines_doc.append(str_line_due_time)
        for i in range(self.num_jobs):
            flag = 0    # 一个写入line每个数据:总工序数、单工序机床数、机床id、时间
            flag_time = 0
            flag_new_ope = 1    # 每个job下每个工序的写入
            idx_ope = -1        # 记录job第几个operation
            idx_ma = 0
            line = []
            option_max = sum(self.nums_option[self.num_ope_biass[i]:(self.num_ope_biass[i]+self.nums_ope[i])])  # 每个job的所有operation可加工机床的总数
            idx_option = 0
            while True:
                if flag == 0:   # 每个job的总工序数 n
                    line.append(self.nums_ope[i])
                    flag += 1
                elif flag == flag_new_ope:  # 跟换工序
                    idx_ope += 1    # job第几个工序
                    idx_ma = 0      # operations第几个机器
                    flag_new_ope += self.nums_option[self.num_ope_biass[i]+idx_ope] * 2 + 1 # 下一个工序的开始数
                    line.append(self.nums_option[self.num_ope_biass[i]+idx_ope])            # 第idx_ope工序的可加工机床数
                    flag += 1
                elif flag_time == 0:    # 跟换机床
                    line.append(self.ope_ma[self.num_ma_biass[self.num_ope_biass[i]+idx_ope] + idx_ma]) # 可用机床的id
                    flag += 1
                    flag_time = 1
                else:
                    line.append(self.proc_time[self.num_ma_biass[self.num_ope_biass[i]+idx_ope] + idx_ma])  # 对应的加工时间
                    flag += 1
                    flag_time = 0
                    idx_option += 1 # 记录写入了多少个机床了
                    idx_ma += 1
                if idx_option == option_max: # 总机床数写满了，换行写新的job
                    str_line = " ".join([str(val) for val in line])
                    #lines.append(str_line + '\n')
                    lines_doc.append(str_line)
                    break
        #lines.append('\n')
        if self.flag_doc:
            doc = open(self.path + '{0}j_{1}m_{2}.fjs'.format(self.num_jobs, self.num_mas, str.zfill(str(idx+1),3)),'a')
            for i in range(len(lines_doc)):
                print(lines_doc[i], file=doc)
            doc.close()

def main():
    with open("./config_make_FJSP_instances.json", 'r') as load_f:
        load_dict = json.load(load_f)
    make_paras = load_dict["make_paras"]

    num_ins = make_paras["num_ins"]
    num_jobs = make_paras["num_jobs"]
    num_mas = make_paras["num_mas"]
    opes_per_job_min = int(num_mas * 0.8)
    opes_per_job_max = int(num_mas * 1.2)

    nums_ope = [random.randint(opes_per_job_min, opes_per_job_max) for _ in range(num_jobs)]
    case = CaseMake(num_jobs, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=nums_ope)

    for i in range(num_ins):
        case.get_case(i)
        print(f"Completed {i} instance")


if __name__ == '__main__':
    main()
