import copy
import json
import os
import random
import time as time
import collections
import gym
import pandas as pd
import torch
import numpy as np
import pynvml
import PPO_model
from gym.envs.registration import register, registry
import env
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True



def main():
    # PyTorch初始化,PyTorch initialization
    # gpu_tracker = MemTracker() #用于监控gpu的内存, gpu_tracker = MemTracker()  # Used to monitor memory (of gpu)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type=='cuda':
        torch.cuda.set_device(device)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
    else:
        torch.set_default_tensor_type('torch.FloatTensor')
    print("PyTorch device: ", device.type)
    torch.set_printoptions(precision=None, threshold=np.inf, edgeitems=None, linewidth=None, profile=None, sci_mode=False)

    # Load config and init objects
    with open("./config-run.json", 'r') as load_f:
        load_dict = json.load(load_f)
    model_paras = load_dict["model_paras"]
    test_paras = load_dict["test_paras"]
    train_paras = load_dict["train_paras"]
    test_paras["device"] = device
    model_paras["device"] = device
    b = test_paras["batch_size"]

    # 从save读取规模算例和对应的模型
    model_path = "./save/"
    model_files = os.listdir(model_path)
    for files in model_files:                   # 规模
        scale = files.split('-')[0]
        num_jobs = int(scale.split('_')[0])
        num_mas = int(scale.split('_')[1])
        model_paras['num_jobs'] = test_paras["num_jobs"] = train_paras["num_jobs"] = num_jobs
        model_paras['num_mas'] = test_paras["num_mas"] = train_paras["num_mas"] = num_mas
        num_ins = test_paras['num_sample']
        limit_time = test_paras["limit_time"][scale]
        # 1.建立模型
        memories = PPO_model.Memory()
        model = PPO_model.PPO(model_paras, train_paras)
        # 1.1读取模型
        folder_path = "./save/" + files + "/models"
        subdirs = [subdir for subdir in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, subdir)) and not subdir.startswith('.')]  # 遍历文件夹下的子文件夹
        sorted_subdirs = sorted(subdirs, key=lambda x: int(x))  # 根据子文件夹名称进行排序
        # 1.2读取非支配层前几层的模型
        models = []
        models_files = []
        top_subdirs = sorted_subdirs[: 3]  # 获取前3个子文件夹路径
        for subdir_name in top_subdirs:
            subdir_path = os.path.join(folder_path, subdir_name)
            for file_name in os.listdir(subdir_path):
                if file_name.endswith('.pt'):
                    models.append(file_name)
                    models_files.append(subdir_path)
        # 1.3建立对应规模的算例的环境
        ins_file_path = "./data_test/" + '{0}{1}/'.format(num_jobs, str.zfill(str(num_mas), 2))
        ins_all_files = os.listdir(ins_file_path)
        # 一个一个的求解
        # 3.循环测试算例
        for i_ins in range(0, num_ins):  # 遍历每个算例
            ins_data_files = ins_file_path + ins_all_files[i_ins]
            # 3.1 采测试算例，第一种方法：选择几个并行一块进行
            env = gym.make('fjsp-v0', case=[ins_data_files] * test_paras["batch_size"], env_paras=test_paras, data_source='file')
            print(
                f"Create env:---{b}*{ins_all_files[i_ins]}-------------------------------------------------------------")
            # 3.2 并行同规模算例，循环遍历模型
            objects = []
            solutions = []
            solutions_time = []
            ins_start = time.time()
            for mod, mod_file in zip(models, models_files):  # 模型
                if device.type == 'cuda':
                    model_CKPT = torch.load(f"{mod_file}/" + mod)  # 训练好的网络权重
                else:
                    model_CKPT = torch.load(f"{mod_file}/" + mod, map_location='cpu')
                print('loading checkpoint:', mod)
                model.policy.load_state_dict(model_CKPT)  # 将保存在 model_CKPT 字典中的权重参数加载到 model.policy 模型
                model.policy_old.load_state_dict(model_CKPT)
                # 3.2.1一个模型遍历几次
                for ii in range(test_paras["range_num"]):  # 每个模型遍历几次
                    object, so_time, solution = schedule(env, model, memories)
                    objects.extend(object.tolist())
                    solutions.extend(solution)
                    solutions_time.append(so_time)
                    print(f"{ii}--finished solutions spend time: {so_time}")
                    env.reset()
                end_time = time.time()
                if (end_time - ins_start) > limit_time:
                    break
            ins_end = time.time()
            print(f"finished instances {ins_all_files[i_ins]} speed time: {ins_end - ins_start}--------------------")
            solutions_time.insert(0, ins_end - ins_start)  # 0：总时间
            # 3.3将解存入文件保存
            solution_line_doc = []
            object_line_doc = []
            time_line_doc = []
            for i in range(len(objects)):
                object_line = " ".join(str(val) for val in objects[i])
                object_line_doc.append(object_line)
                solution_line_doc.append(object_line)
                for j in range(len(solutions[i])):
                    solution_line = " ".join([str(int(val)) for val in solutions[i][j]])
                    solution_line_doc.append(solution_line)
                solution_line_doc.append('')
            for t in solutions_time:
                time_line_doc.append(str(t))
            # 3.4保存
            save_file = './data_solution/' + f"{num_jobs}-{num_mas}/" + os.path.splitext(ins_all_files[i_ins])[0] + "/HGAN-all"
            os.makedirs(save_file, exist_ok=True)
            doc_solution = open(save_file + '/solution.fjs', 'a')
            for i in range(len(solution_line_doc)):
                print(solution_line_doc[i], file=doc_solution)
            doc_solution.close()
            doc_object = open(save_file + '/object.fjs', 'a')
            for i in range(len(object_line_doc)):
                print(object_line_doc[i], file=doc_object)
            doc_object.close()
            doc_time = open(save_file + '/time.fjs', 'a')
            for i in range(len(time_line_doc)):
                print(time_line_doc[i], file=doc_time)
            doc_time.close()
            print(f"finished instances {ins_all_files[i_ins]}-save-----------------")
        print(f"finished all {num_ins} instances")
def schedule(env, model, memories):
    # Get state and completion signal
    state = env.state
    dones = env.done_batch
    done = False  # Unfinished at the beginning
    last_time = time.time()
    while ~done:
        with torch.no_grad():
            actions, object = model.policy_old.act(state, memories, flag_train=False)
        state, rewards, dones = env.step(actions, object)  # environment transit
        done = dones.all()
    spend_time = time.time() - last_time  # 解决此环境(实例)所花费的时间,The time taken to solve this environment (instance)
    #print("all_action_spend_time: ", spend_time)
    makespan_batch = copy.deepcopy(env.makespan_batch)
    TR_batch = copy.deepcopy(env.ob_TR)
    energy_batch = copy.deepcopy(env.ob_energy)
    object = torch.stack([makespan_batch, energy_batch, TR_batch], dim=1)
    solutions = copy.deepcopy(env.used.tolist())
    # 验证解决方案,Verify the solution
    gantt_result = env.validate_gantt()[0]
    if not gantt_result:
        print("Scheduling Error！！！！！！")
    return object, spend_time, solutions


if __name__ == '__main__':
    main()