import copy
import json
import os
import random
import time
from collections import deque

import gym
import pandas as pd
import torch
import numpy as np
from visdom import Visdom

import PPO_model
from env.case_generator import CaseGenerator
from validate import validate, get_validate_env
from sorting import non_dominated_sorting

#  python -m visdom.server
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def main():
    # PyTorch initialization
    # gpu_tracker = MemTracker()  # Used to monitor memory (of gpu)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type == 'cuda':
        torch.cuda.set_device(device)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
    else:
        torch.set_default_tensor_type('torch.FloatTensor')
    print("PyTorch device: ", device.type)
    torch.set_printoptions(precision=None, threshold=np.inf, edgeitems=None, linewidth=None, profile=None, sci_mode=False)

    # Load config and init objects
    with open("./config.json", 'r') as load_f:
        load_dict = json.load(load_f)
    env_paras = load_dict["env_paras"]
    model_paras = load_dict["model_paras"]
    train_paras = load_dict["train_paras"]
    env_paras["device"] = device
    model_paras["device"] = device
    env_valid_paras = copy.deepcopy(env_paras)
    env_valid_paras["batch_size"] = env_paras["valid_batch_size"]

    num_jobs = env_paras["num_jobs"]
    num_mas = env_paras["num_mas"]
    opes_per_job_min = int(num_mas * 0.8)
    opes_per_job_max = int(num_mas * 1.2)

    memories = PPO_model.Memory()
    model = PPO_model.PPO(model_paras, train_paras, num_envs=env_paras["batch_size"])
    env_valid = get_validate_env(env_valid_paras)  # 创建一个验证环境，Create an environment for validation
    models_name = []
    models_scores = []

    # Use visdom to visualize the training process
    is_viz = train_paras["viz"]
    if is_viz:
        viz = Visdom(env=train_paras["viz_name"])

    # 生成数据文件并填写标题,Generate data files and fill in the header
    str_time = time.strftime("%Y%m%d_%H%M%S", time.localtime(time.time()))
    save_path = './save/train_{0}'.format(str_time)
    os.makedirs(save_path)
    path_loss = save_path + '/loss.xlsx'
    writer_loss = pd.ExcelWriter(path_loss, model='w', engine='openpyxl')
    data_loss = pd.DataFrame(np.arange(1, train_paras["max_iterations"]+1, 1), columns=["iterations"])
    data_loss.to_excel(writer_loss, sheet_name='Sheet1', index=False)
    # 训练曲线存储路径(验证集平均值).Training curve storage path (average of validation set)
    path_ave = save_path + '/training_ave_{0}.xlsx'.format(str_time)
    writer_ave = pd.ExcelWriter(path_ave, mode='w', engine='openpyxl')
    # 训练曲线存储路径(每个验证实例的值),Training curve storage path (value of each validating instance)
    path_sig = save_path + '/training_100_{0}.xlsx'.format(str_time)
    writer_sig = pd.ExcelWriter(path_sig, mode='w', engine='openpyxl')
    data_file = pd.DataFrame(np.arange(train_paras["save_timestep"], train_paras["max_iterations"]+1, train_paras["save_timestep"]), columns=["iterations"])
    data_file.to_excel(writer_ave, sheet_name='Sheet1', index=False)
    writer_ave.save()
    data_file = pd.DataFrame(np.arange(train_paras["save_timestep"], train_paras["max_iterations"]+1, train_paras["save_timestep"]), columns=["iterations"])
    data_file.to_excel(writer_sig, sheet_name='Sheet1', index=False)
    writer_sig.save()
    p = train_paras["parallel_iter"]
    s = train_paras["save_timestep"]

    valid_results_sig = []
    valid_results_ave = []
    reward_loss_data = []
    # Start training iteration
    start_time = time.time()
    env = None
    for i in range(1, train_paras["max_iterations"]+1):
        # Replace training instances every x iteration (x = 20 in paper)
        if (i - 1) % train_paras["parallel_iter"] == 0:
            # \mathcal{B} 实例使用一致的操作来加速训练,instances use consistent operations to speed up training
            print(f"-------------------------------------{(i - 1) // p}---算例-------------------------------------")
            nums_ope = [random.randint(opes_per_job_min, opes_per_job_max) for _ in range(num_jobs)]
            case = CaseGenerator(num_jobs, num_mas, opes_per_job_min, opes_per_job_max, nums_ope=nums_ope)
            env = gym.make('fjsp-v0', case=case, env_paras=env_paras)
            print(" ")

        # Get state and completion signal
        state = env.state
        done = False
        dones = env.done_batch
        last_time = time.time()
        # Schedule in parallel
        while ~done:
            with torch.no_grad():
                actions, object = model.policy_old.act(state, memories)
            state, rewards, dones = env.step(actions, object)   # 将self.state中的参数更新改变
            done = dones.all()
            memories.rewards.append(rewards)
            memories.is_terminals.append(dones)
            # gpu_tracker.track()  # Used to monitor memory (of gpu)
        print(f"---------{i}-解-({(i - 1)//p}算例)----------")
        print(f"makespan:{env.makespan_batch.tolist()}  ob_energy:{env.ob_energy.tolist()} ob_tardiness:{env.ob_TR.tolist()}")
        print(f"---all_action_spend_time: {time.time()-last_time}")
        # 验证解决方案,Verify the solution
        gantt_result = env.validate_gantt()[0]  # 检查对工序、机床的安排是否合理，没有出现时间上的重叠错误
        if not gantt_result:
            print("Scheduling Error！！！！！！")
        # print("Scheduling Finish")
        env.reset() # 恢复原先的状态 参数数据 v

        # if iter mod x = 0 then update the policy (x = 1 in paper)
        if i % train_paras["update_timestep"] == 0:
            reward_loss = model.update(memories, env_paras, train_paras)
            print(f"--------{i//1}-参数-({(i - 1)//p}算例)----------")
            print("reward, loss: ", reward_loss)
            reward_loss_data.append(reward_loss)
            print(" ")
            memories.clear_memory()

        # if iter mod x = 0 then validate the policy (x = 10 in paper)
        if i % train_paras["save_timestep"] == 0:
            print(f"------------------------------------{i}--验证------------------------------")
            print('Start validating')
            # 记录平均结果和每个实例的结果,Record the average results and the results on each instance
            makespan_mean, makespan_batch, energy_mean, energy_batch, TR_mean, TR_batch= validate(env_valid_paras, env_valid, model.policy_old)
            vali_result_ave = torch.cat([makespan_mean.unsqueeze(0), energy_mean.unsqueeze(0), TR_mean.unsqueeze(0)])
            valid_results_ave.append(vali_result_ave.tolist())
            vali_result_sig = torch.cat([makespan_batch, energy_batch, TR_batch])
            valid_results_sig.append(vali_result_sig.tolist())
            # 对模型保存
            models_path = save_path + "/models"
            if not os.path.exists(models_path):
                os.makedirs(models_path)
            save_file = '{0}/save_{1}_{2}_{3}.pt'.format(models_path, num_jobs, num_mas, i)
            torch.save(model.policy.state_dict(), save_file)
            models_name.append(f'save_{num_jobs}_{num_mas}_{i}.pt')
            models_scores.append(vali_result_ave)
        end_time = time.time()
        #if (end_time-start_time) > 800:
            #break
    print("total_time: ", time.time() - start_time)
    non_dominated_sorting(models_name, models_scores, save_path)
    valid_sig_data = [[round(num_sig, 3) for num_sig in sublist_sig] for sublist_sig in valid_results_sig]
    valid_ave_data = [[round(num_ave, 3) for num_ave in sublist_ave] for sublist_ave in valid_results_ave]
    columns_sig = []
    for c in range(env_paras["valid_batch_size"]):
        columns_sig.append("makespan{}".format(c))
    for c in range(env_paras["valid_batch_size"]):
        columns_sig.append("energy{}".format(c))
    for c in range(env_paras["valid_batch_size"]):
        columns_sig.append("tardiness{}".format(c))
    v_s_d = pd.DataFrame(valid_sig_data, columns=columns_sig)
    v_s_d.to_excel(writer_sig, sheet_name='Sheet1', index=False, startcol=1)
    writer_sig.save()
    writer_sig.close()

    v_a_d = pd.DataFrame(valid_ave_data, columns=["makespan", "energy", "tardiness"])
    v_a_d.to_excel(writer_ave,  sheet_name='Sheet1', index=False, startcol=1)
    writer_ave.save()
    writer_ave.close()

    rl = pd.DataFrame(reward_loss_data, columns=["reward", "actor0_loss", "critic0_loss", "actor1_loss", "critic1_loss", "lstm_mlp_loss"])
    rl.to_excel(writer_loss, sheet_name='Sheet1', index=False, startcol=1)
    writer_loss.save()
    writer_loss.close()



if __name__ == '__main__':
    main()