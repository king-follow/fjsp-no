import sys
import gym
import torch

from dataclasses import dataclass
from env.load_data import load_fjs, nums_detec
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import random
import copy
from public import amend_star_time, amend_end_time
from utils.my_utils import read_json, write_json
import torch.nn.functional as F


@dataclass
class EnvState:
    '''
    Class for the state of the environment
    '''
    lstm_inits: list = None

    # static
    opes_appertain_batch: torch.Tensor = None
    ope_pre_adj_batch: torch.Tensor = None
    ope_sub_adj_batch: torch.Tensor = None
    num_ope_biases_batch: torch.Tensor = None
    end_ope_biases_batch: torch.Tensor = None
    nums_opes_batch: torch.Tensor = None

    # dynamic
    batch_idxes: torch.Tensor = None
    feat_opes_batch: torch.Tensor = None
    feat_mas_batch: torch.Tensor = None
    feat_used_batch: torch.Tensor = None
    feat_old_used_batch: torch.Tensor = None
    proc_times_batch: torch.Tensor = None
    gat_opes_adj_batch: torch.Tensor = None
    ope_ma_adj_batch: torch.Tensor = None
    opes_adj_batch: torch.Tensor = None
    unope_ma_adj_batch: torch.Tensor = None
    time_batch: torch.Tensor = None
    ma_time_batch: torch.Tensor = None
    ma_work_time_batch: torch.Tensor = None
    opes_end_times_batch: torch.Tensor = None

    ob_TWT_batch: torch.Tensor = None
    ob_Uave_batch: torch.Tensor = None
    ob_Wstd_batch: torch.Tensor = None
    day_batch: torch.Tensor = None
    opes_time_batch: torch.Tensor = None
    op_st_ma_time_batch: torch.Tensor = None
    la_op_com_T_batch: torch.Tensor = None
    job_due_time_batch: torch.Tensor = None
    tar_opes_batch: torch.Tensor = None
    op_com_batch: torch.Tensor = None
    op_uncom_batch: torch.Tensor = None
    proc_times_avr_batch: torch.Tensor = None

    used_batch: torch.Tensor = None
    mask_job_procing_batch: torch.Tensor = None
    mask_job_finish_batch: torch.Tensor = None
    mask_ma_procing_batch: torch.Tensor = None
    ope_step_batch: torch.Tensor = None


    def update(self, batch_idxes, feat_opes_batch, feat_mas_batch, feat_used_batch, feat_old_used_batch, proc_times_batch,opes_time_batch, gat_opes_adj_batch, ope_ma_adj_batch,opes_adj_batch,
               mask_job_procing_batch, mask_job_finish_batch, mask_ma_procing_batch, ope_step_batch, time, ma_time_batch,op_st_ma_time_batch,
               ma_work_time_batch,la_op_com_T_batch,used_batch, tar_opes_batch, op_com_batch, op_uncom_batch, opes_end_times_batch, proc_times_avr_batch):
        self.batch_idxes = batch_idxes
        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch
        self.feat_used_batch = feat_used_batch
        self.feat_old_used_batch = feat_old_used_batch
        self.proc_times_batch = proc_times_batch
        self.gat_opes_adj_batch = gat_opes_adj_batch
        self.opes_time_batch = opes_time_batch
        self.ope_ma_adj_batch = ope_ma_adj_batch
        self.opes_adj_batch = opes_adj_batch

        self.mask_job_procing_batch = mask_job_procing_batch
        self.mask_job_finish_batch = mask_job_finish_batch
        self.mask_ma_procing_batch = mask_ma_procing_batch
        self.ope_step_batch = ope_step_batch
        self.time_batch = time
        self.ma_time_batch = ma_time_batch
        self.op_st_ma_time_batch = op_st_ma_time_batch
        self.la_op_com_T_batch = la_op_com_T_batch
        self.ma_work_time_batch = ma_work_time_batch
        self.used_batch = used_batch
        self.tar_opes_batch = tar_opes_batch
        self.op_com_batch = op_com_batch
        self.op_uncom_batch = op_uncom_batch
        self.opes_end_times_batch = opes_end_times_batch
        self.proc_times_avr_batch = proc_times_avr_batch

def convert_feat_job_2_ope(feat_job_batch, opes_appertain_batch):
    '''
    Convert job features into operation features (such as dimension)
    '''
    return feat_job_batch.gather(1, opes_appertain_batch)

class FJSPEnv(gym.Env):
    '''
    FJSP environment
    '''
    def __init__(self, case, env_paras, data_source='case'):
        '''
        :param case: The instance generator or the addresses of the instances
        :param env_paras: A dictionary of parameters for the environment
        :param data_source: Indicates that the instances came from a generator or files
        '''

        # load paras
        # static

        self.batch_size = env_paras["batch_size"]  # Number of parallel instances during training
        self.num_jobs = env_paras["num_jobs"]  # Number of jobs
        self.num_mas = env_paras["num_mas"]  # Number of machines
        self.paras = env_paras  # Parameters
        self.device = env_paras["device"]  # Computing device for PyTorch
        # load instance
        num_data = 10  # The amount of data extracted from instance
        tensors = [[] for _ in range(num_data)]
        self.num_opes = 0
        lines = []
        if data_source=='case':  # Generate instances through generators
            for i in range(self.batch_size):
                lines.append(case.get_case(i)[0])  # Generate an instance and save it
                num_jobs, num_mas, num_opes, num_unopes = nums_detec(lines[i])
                self.num_opes = max(self.num_opes, num_opes)
        else:  # Load instances from files
            for i in range(self.batch_size):
                with open(case[i]) as file_object:
                    line = file_object.readlines()
                    lines.append(line)
                num_jobs, num_mas, num_opes, num_unopes = nums_detec(lines[i])
                self.num_opes = max(self.num_opes, num_opes)
        self.num_unopes = num_unopes
        # load feats
        for i in range(self.batch_size):
            load_data = load_fjs(lines[i], num_mas, self.num_opes)  # 讲FJSP进行解码
            for j in range(num_data):
                tensors[j].append(load_data[j])


        self.proc_times_batch = torch.stack(tensors[0], dim=0)
        self.ope_ma_adj_batch = torch.stack(tensors[1], dim=0).float()
        self.unope_ma_adj_batch = torch.stack(tensors[8], dim=0)
        # for calculating the cumulative amount along the path of each job
        self.cal_cumul_adj_batch = torch.stack(tensors[7], dim=0).float()

        # static feats
        # shape: (batch_size, num_opes, num_opes)
        self.ope_pre_adj_batch = torch.stack(tensors[2], dim=0)
        # shape: (batch_size, num_opes, num_opes)
        self.ope_sub_adj_batch = torch.stack(tensors[3], dim=0)
        # shape: (batch_size, num_opes), represents the mapping between operations and jobs
        self.opes_appertain_batch = torch.stack(tensors[4], dim=0).long()
        # shape: (batch_size, num_jobs), the id of the first operation of each job
        self.num_ope_biases_batch = torch.stack(tensors[5], dim=0).long()
        # shape: (batch_size, num_jobs), the number of operations for each job
        self.nums_ope_batch = torch.stack(tensors[6], dim=0).long()
        self.job_due_time = torch.stack(tensors[9], dim=0)          # due time

        # shape: (batch_size, num_jobs), the id of the last operation of each job,可以说是每个算例的每个job的最后的工序数
        self.end_ope_biases_batch = self.num_ope_biases_batch + self.nums_ope_batch - 1
        # shape: (batch_size), the number of operations for each instance，每个算例的总工序数
        self.nums_opes = torch.sum(self.nums_ope_batch, dim=1)

        # dynamic variable
        self.batch_idxes = torch.arange(self.batch_size)                                # Uncompleted instances, 0 1 2 3 4 5 6 7 8 9
        self.time = torch.zeros(self.batch_size)                                        # action time min
        self.worker_time = torch.zeros(size=(self.batch_size, self.num_mas))            # worker time
        self.day = torch.zeros(size=(self.batch_size, self.num_mas))                    # machine time
        self.ma_time = torch.zeros(size=(self.batch_size, self.num_mas))                # 记录每个机床的时间，就是下一个工序加工的最早时间看，如果加班，这个机器时间记录的是下一个最早的时间
        self.op_st_ma_time = torch.zeros(size=(self.batch_size, self.num_opes))         # 记录当前工序加工时的机床时间
        self.ma_work_time = torch.zeros(size=(self.batch_size, self.num_mas))           # 在当前机床的加工时间
        self.ma_unwork_time = torch.zeros(size=(self.batch_size, self.num_mas))         # 记录每个机床的空闲时间(在工作时间内)
        self.la_op_com_T = torch.zeros(size=(self.batch_size, self.num_jobs))           # 记录每个工件已完成最后工序的完工时间
        self.N = torch.zeros(self.batch_size).int()  # Count scheduled operations
        self.ope_step_batch = copy.deepcopy(self.num_ope_biases_batch)                  # 记录每个job 的开始工序
        self.used = torch.zeros(size=(self.batch_size,self.num_opes, self.num_mas + 9))
        self.opes_added = torch.zeros(size=(self.batch_size, self.num_opes))            # 记录每个opes的加班情况
        self.tar_opes = torch.zeros(size=(self.batch_size, self.num_opes))              # 每个工序是否延迟

        self.ob_TWT = torch.zeros(self.batch_size)                                      # 总加权延误
        self.ob_Uave = torch.zeros(self.batch_size)                                     # 平均机器利用率
        self.ob_Wstd = torch.zeros(self.batch_size)                                     # 机器工作负载
        self.ob_energy = torch.zeros(self.batch_size)                                   # 总能耗：工人能耗+机器能耗，工人能耗=时间*工人+机器*电费
        self.ob_TR = torch.zeros(self.batch_size)                                          # 延迟率
        self.op_com = torch.zeros(size=(self.batch_size, self.num_jobs))                # 已经完成的工序
        self.op_uncom = self.nums_ope_batch - self.op_com                               # 未完成的工序
        self.add_time = torch.zeros(size=(self.batch_size, self.num_mas))               # 记录每个job的总加班时间
        #self.delay_time = torch.zeros(size=(self.batch_size, self.num_jobs))           # 记录每个job的总延期时间

        self.tar_e_op_ucom = torch.zeros(size=(self.batch_size, self.num_jobs))         # 估计迟到的工序数(未加工的工序)
        self.tar_a_op_ucom = torch.zeros(size=(self.batch_size, self.num_jobs))         # 实际迟到的工序数(已加工的工序)
        self.com_job_rate = torch.zeros(size=(self.batch_size, self.num_jobs))          # job的完工率


        '''
        features, dynamic
            ope:  size = 10+机床数
                0 Status,状态
                1 Number of neighboring machines，机器的邻居N_t(M_k) : M_k 相邻的工序操作，M_k能操作哪几个工序===operations
                2 Processing time，处理时间
                3 Number of unscheduled operations in the job，未安排完成的工序
                4 Job completion time，job完成时间
                5 Start time，开始时间
                6 是否是可中断
                7 是否加班
                8 job截至时间
                9 due_time 的完成情况，1：还都未完成
                10 机床_0
                11 机床_1
                ...
                9+n_m 机床_n_m
            ma:   size = 5+工件数
                0 Number of neighboring operations，工序的邻居N_t(O_ij) : O_ij 的相邻的机器，O_ij能被哪几个机床加工====machines
                1 Available time,可用时间, 当前机床可以加工的待加工工序数总和
                2 Utilization，使用率
                3 当天对应的标准时间(8h)
                4 机床未利用的时间
                5 工序_0
                ...
                4+n_o 工序_n_j
            used:    size = 20
                0 机器总数
                1 机器的平均利用率
                2 机器的平均利用率标准差
                3 总工序完成率
                4 每个job的完成率
                5 每个job的完成率标准差
                6 机器工作量归一化平均
                7 机器工作量归一化平均标准差
                8 估算延迟率
                9 实际延迟率
        '''
        # Generate raw feature vectors
        feat_opes_batch = torch.zeros(size=(self.batch_size, self.paras["ope_feat_dim"]+self.num_mas, self.num_opes)) # batch_size, 6*num_opes
        feat_mas_batch = torch.zeros(size=(self.batch_size, self.paras["ma_feat_dim"]+self.num_jobs, num_mas)) # batch_size, 3*num_mas
        feat_used_batch = torch.rand(size=(self.batch_size, self.paras["use_feat_dim"]))

        feat_opes_batch[:, 1, :] = torch.count_nonzero(self.ope_ma_adj_batch, dim=2)                                    # 每个工序可用的机床数
        feat_opes_batch[:, 2, :] = torch.sum(self.proc_times_batch, dim=2).div(feat_opes_batch[:, 1, :] + 1e-9)         # 平均时间
        feat_opes_batch[:, 3, :] = convert_feat_job_2_ope(self.nums_ope_batch, self.opes_appertain_batch)               # gather()函数融合
        feat_opes_batch[:, 5, :] = torch.bmm(feat_opes_batch[:, 2, :].unsqueeze(1), self.cal_cumul_adj_batch).squeeze() # 开始时间
        feat_opes_batch[:, 5, :] = amend_star_time(self.num_jobs, self.nums_ope_batch[self.batch_idxes,:], self.num_ope_biases_batch[self.batch_idxes], feat_opes_batch[self.batch_idxes, 5, :])
        end_time = feat_opes_batch[:, 5, :] + feat_opes_batch[:, 2, :]
        end_times = amend_end_time(end_time[self.batch_idxes], feat_opes_batch[:, 2, :], feat_opes_batch[:, 7, :])      # 标准化结束时间
        end_time_batch = end_times.gather(1, self.end_ope_biases_batch)                                                 # 对各个job的估算完成时间
        feat_opes_batch[:, 4, :] = convert_feat_job_2_ope(end_time_batch, self.opes_appertain_batch)                    # 完工时间
        feat_opes_batch[:, 6, :] = copy.deepcopy(self.unope_ma_adj_batch[:,:,-1])                                       # 是否中断，1:中断，0:不可中断
        feat_opes_batch[:, 8, :] = convert_feat_job_2_ope(self.job_due_time, self.opes_appertain_batch)                 # job截至时间
        urg_opes = (self.job_due_time-self.la_op_com_T).div(self.job_due_time)
        feat_opes_batch[:, 9, :] = convert_feat_job_2_ope(urg_opes, self.opes_appertain_batch)                          # job的工序的完成情况

        self.gat_opes_adj_batch = torch.zeros(size=(self.batch_size, self.num_opes, self.num_opes + self.num_mas))      # 计算GAT的opes_adj
        # 创建整体的节点-节点之间的特征图, 只有工序节点之间的关系
        self.opes_adj_batch = torch.full(size=(self.batch_size, self.num_opes, self.num_opes + self.num_mas), dtype=torch.float, fill_value = float('-inf'))
        for batch in range(self.batch_size):
            ope_step_batch = self.ope_step_batch[batch]                 # 记录每个job的待加工工序
            sta_ope_biases_batch = self.num_ope_biases_batch[batch]     # 每个job的开始的一个工序
            end_ope_biases_batch = self.end_ope_biases_batch[batch]     # 每个job的最后的一个工序
            ope_ma_adj_batch = copy.deepcopy(self.ope_ma_adj_batch[batch])
            # 处理工序之间的关系ta
            for ope_0 in range(self.num_opes):
                job_0 = torch.where(((sta_ope_biases_batch <= ope_0)*(ope_0 <= end_ope_biases_batch)) == True)[0]
                if ope_0 in ope_step_batch:                             # 说明是下一步待加工的工序，循环全部
                    for ope_1 in range(self.num_opes):                  # 循环全部
                        job_1 = torch.where(((sta_ope_biases_batch <= ope_1) * (ope_1 <= end_ope_biases_batch)) == True)[0]                 # 当前工序属于那个job
                        if (job_0 == job_1) and (sta_ope_biases_batch[job_1] <= ope_1) and (ope_1 <= end_ope_biases_batch[job_1]):          # 相同job工序间的关系
                            self.opes_adj_batch[batch][ope_0][ope_1] = ope_1 - ope_0                                                        # 记录前后工序得关系
                        elif (job_0 != job_1) and ((sta_ope_biases_batch[job_1] <= ope_1) and (ope_1 <= end_ope_biases_batch[job_1])):      # 不同job工序间的关系
                            self.opes_adj_batch[batch][ope_0][ope_1] = (ope_1 - sta_ope_biases_batch[job_1]) - (ope_0 - sta_ope_biases_batch[job_0])        # 相对工序得层次位置
                else:                                                   # 非待加工工序，只修改本job工序
                    for ope_1 in range(sta_ope_biases_batch[job_0], end_ope_biases_batch[job_0]+1):
                        self.opes_adj_batch[batch][ope_0][ope_1] = ope_1 - ope_0
            for j in range(self.num_jobs):
                st = sta_ope_biases_batch[j]
                en = end_ope_biases_batch[j]
                for i in range(st, en):
                    self.gat_opes_adj_batch[batch][i][i+1] = feat_opes_batch[:, 2, :][batch][i]
            self.gat_opes_adj_batch[batch, :, self.num_opes:] = self.proc_times_batch[batch]
            self.opes_adj_batch[batch, :, self.num_opes:] = ope_ma_adj_batch.masked_fill(self.ope_ma_adj_batch[batch]==0, float('-inf'))

        # 加工时间塞入operation_feat中
        for i in range(self.num_mas):
            feat_opes_batch[:, 10+i, :] = self.proc_times_batch[:,:,i]
        # 将下一步待加工的工序时间塞入machine_feat中：
        feat_mas_batch[:, 5:, :] = self.proc_times_batch.gather(1, self.ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.shape[-1]))

        feat_mas_batch[:, 0, :] = torch.count_nonzero(self.ope_ma_adj_batch, dim=1)        # 当前机床可以加工的工序数总和
        feat_mas_batch[:, 1, :] = torch.count_nonzero(self.ope_ma_adj_batch.gather(1, self.ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.shape[-1])), dim=1)        # 当前机床可以加工的待加工工序数总和
        feat_mas_batch[:, 3, :] = torch.full(size = feat_mas_batch[:, 3, :].size(), fill_value= 8)      # 当天对应的标准时间(8h)
        # 每个工序的处理时间
        self.opes_time = torch.sum(self.proc_times_batch, dim=2).div(feat_opes_batch[:, 1, :] + 1e-9)   # 用于工序计算的时间

        self.opes_end_times = copy.deepcopy(end_times)
        self.proc_times_avr = copy.deepcopy(feat_opes_batch[:, 2, :])
        # 估算延迟的工序数
        self.tar_opes = torch.where(end_times > feat_opes_batch[:, 8, :], 1, 0)
        for batch in range(self.batch_size):
            self.tar_e_op_ucom[batch] = torch.tensor([torch.sum(self.tar_opes[batch][star:end+1]) for star, end in zip(self.ope_step_batch[batch], self.end_ope_biases_batch[batch])])
            self.tar_a_op_ucom[batch] = torch.tensor([torch.sum(self.tar_opes[batch][star:end]) for star, end in zip(self.num_ope_biases_batch[batch], self.ope_step_batch[batch])])

        #feat_used_batch[:, 0] = feat_used_batch[:,10] = copy.deepcopy(self.num_mas)
        self.feat_old_used_batch = copy.deepcopy(feat_used_batch[:, :10])      # 保存上一个状态10个值


        self.feat_opes_batch = feat_opes_batch
        self.feat_mas_batch = feat_mas_batch
        self.feat_used_batch = feat_used_batch

        # Masks of current status, dynamic
        # shape: (batch_size, num_jobs), True for jobs in process,
        self.mask_job_procing_batch = torch.full(size=(self.batch_size, num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_jobs), True for completed jobs
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, num_jobs), dtype=torch.bool, fill_value=False)
        # shape: (batch_size, num_mas), True for machines in process
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, num_mas), dtype=torch.bool, fill_value=False)
        '''
        Partial Schedule (state) of jobs/operations, dynamic
            0 Status,状态
            1 Allocated machines，分配的机器
            2 Start time，开始时间
            3 End time，完成时间
        '''
        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 4))
        self.schedules_batch[:, :, 2] = feat_opes_batch[:, 5, :]
        self.schedules_batch[:, :, 3] = end_times
        '''
        Partial Schedule (state) of machines, dynamic
            0 idle，空闲
            1 available_time，可用时间
            2 utilization_time，利用时间
            3 id_ope，工序的job id,第几个job
        '''
        self.machines_batch = torch.zeros(size=(self.batch_size, self.num_mas, 4))
        self.machines_batch[:, :, 0] = torch.ones(size=(self.batch_size, self.num_mas))

        self.makespan_batch = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]  # shape: (batch_size)
        self.ob_penalty = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]

        # 工人工资
        worker_pay = (self.paras['one_mac_workers']*(self.paras['worker_pay']*self.makespan_batch.unsqueeze(1).expand(-1, self.num_mas) + self.paras['worker_add_pay']*self.add_time)).sum(dim=1)
        # 机器消耗电费
        machine_pay = (self.makespan_batch.unsqueeze(1).expand(-1, self.num_mas)*self.paras['work_electric'] + self.ma_unwork_time*self.paras['unwork_electric'] + self.add_time*self.paras['work_add_electric']).sum(dim=1)
        # 目标能耗
        self.ob_energy = worker_pay + machine_pay
        max_objective = 0.4*self.makespan_batch + 0.3*self.ob_energy + 0.3*self.ob_TR
        self.max_objective = max_objective

        self.done_batch = self.mask_job_finish_batch.all(dim=1)  # shape: (batch_size)

        self.state = EnvState(
                              lstm_inits=[],
                              batch_idxes=self.batch_idxes,
                              feat_opes_batch=self.feat_opes_batch,
                              feat_mas_batch=self.feat_mas_batch,
                              feat_used_batch=self.feat_used_batch,
                              feat_old_used_batch=self.feat_old_used_batch,
                              proc_times_batch=self.proc_times_batch,
                              gat_opes_adj_batch=self.gat_opes_adj_batch,
                              ope_ma_adj_batch=self.ope_ma_adj_batch,
                              opes_adj_batch=self.opes_adj_batch,
                              unope_ma_adj_batch=self.unope_ma_adj_batch,
                              ope_pre_adj_batch=self.ope_pre_adj_batch,
                              ope_sub_adj_batch=self.ope_sub_adj_batch,
                              opes_time_batch=self.opes_time,
                              mask_job_procing_batch=self.mask_job_procing_batch,
                              mask_job_finish_batch=self.mask_job_finish_batch,
                              mask_ma_procing_batch=self.mask_ma_procing_batch,
                              opes_appertain_batch=self.opes_appertain_batch,
                              ope_step_batch=self.ope_step_batch,
                              num_ope_biases_batch=self.num_ope_biases_batch,
                              end_ope_biases_batch=self.end_ope_biases_batch,
                              opes_end_times_batch=self.opes_end_times,
                              proc_times_avr_batch=self.proc_times_avr,
                              nums_opes_batch=self.nums_opes,
                              time_batch=self.time,
                              ma_time_batch=self.ma_time,
                              op_st_ma_time_batch=self.op_st_ma_time,
                              ma_work_time_batch=self.ma_work_time,
                              la_op_com_T_batch=self.la_op_com_T,
                              job_due_time_batch=self.job_due_time,
                              op_com_batch = self.op_com,
                              op_uncom_batch = self.op_uncom,
                              ob_TWT_batch=self.ob_TWT,
                              ob_Uave_batch=self.ob_Uave,
                              ob_Wstd_batch=self.ob_Wstd,
                              day_batch=self.day,
                              used_batch=self.used,
                              tar_opes_batch=self.tar_opes)

        # Save initial data for reset
        self.old_proc_times_batch = copy.deepcopy(self.proc_times_batch)
        self.old_ope_ma_adj_batch = copy.deepcopy(self.ope_ma_adj_batch)
        self.old_unope_ma_adj_batch = copy.deepcopy(self.unope_ma_adj_batch)
        self.old_cal_cumul_adj_batch = copy.deepcopy(self.cal_cumul_adj_batch)
        self.old_opes_time = copy.deepcopy(self.opes_time)
        self.old_feat_opes_batch = copy.deepcopy(self.feat_opes_batch)
        self.old_feat_mas_batch = copy.deepcopy(self.feat_mas_batch)
        self.old_feat_used_batch = copy.deepcopy(self.feat_used_batch)
        self.old_state = copy.deepcopy(self.state)
        self.old_job_due_time = copy.deepcopy(self.job_due_time)
        self.old_opes_adj_batch = copy.deepcopy(self.opes_adj_batch)
        self.old_gat_opes_adj_batch = copy.deepcopy(self.gat_opes_adj_batch)

    def step(self, actions, objectives):
        '''
        Environment transition function
        '''
        opes = copy.deepcopy(actions[0, :])
        mas = copy.deepcopy(actions[1, :])
        jobs = copy.deepcopy(actions[2, :])
        objectives = copy.deepcopy(objectives)
        #print(objectives.tolist())
        self.N += 1     # 第几步选择了

        # Removed unselected O-M arcs of the scheduled operations
        remain_ope_ma_adj = torch.zeros(size=(self.batch_size, self.num_mas), dtype=torch.float)    # Size([4, 5])
        remain_ope_ma_adj[self.batch_idxes, mas] = 1                                                # 标记使用的机床,将选择的机床置为1
        self.ope_ma_adj_batch[self.batch_idxes, opes] = remain_ope_ma_adj[self.batch_idxes, :]      # 改变矩阵信息(改变ope_ma_adj_batch的对应选择工序的机床)
        self.proc_times_batch *= self.ope_ma_adj_batch                                              # 对其他未选择的机床置为0

        # Update for some O-M arcs are removed, such as 'Status', 'Number of neighboring machines' and 'Processing time'，删除了一些O-M弧的更新，如“状态”，“相邻机器的数量”和“处理时间”
        proc_times = self.proc_times_batch[self.batch_idxes, opes, mas] # 选择的工序对应机床的加工时间
        self.feat_opes_batch[self.batch_idxes, :3, opes] = torch.stack((torch.ones(self.batch_idxes.size(0), dtype=torch.float),
                                                                        torch.ones(self.batch_idxes.size(0), dtype=torch.float),
                                                                        proc_times), dim=1)         # 改变machine embedding输入的6维数据的前三维
        self.opes_time[self.batch_idxes, opes] = proc_times

        # 改变feat_opes_batch 的第 3 (工序的邻居)维数据，Update 'Number of unscheduled operations in the job',更新“作业中计划外操作的数量”，改变
        start_ope = self.num_ope_biases_batch[self.batch_idxes, jobs]   #([28, 15, 15, 34])
        end_ope = self.end_ope_biases_batch[self.batch_idxes, jobs] #([33, 18, 18, 37])
        for i in range(self.batch_idxes.size(0)):
            self.feat_opes_batch[self.batch_idxes[i], 3, start_ope[i]:end_ope[i]+1] -= 1            # 改变 工序的邻居(第 3 维)

        # for 每个batch 来计算吧
        end_t_batch = []
        add_time = torch.zeros(self.batch_size)
        daly_time = torch.zeros(self.batch_size)
        for idex in self.batch_idxes:
            batch_idxes = idex
            #  1. 是否中断,   1:可中断    0：不可中断
            is_inter = self.unope_ma_adj_batch[batch_idxes, opes[batch_idxes], -1]
            # 2. 计算当天机器的可用时间
            u = 8 - (torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]]) % 24)
            # 3.1 可用时间 >= 加工时间
            if u >= proc_times[batch_idxes] > 0:
                # 3.1.1 计算工序的开始时间，max(机床时间， 上一个工序完工时间)
                opes_star_time = torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]])
                # 3.1.2 判断操作工序是否是job的首个工序，用于矩阵相乘估算每个工序的完工时间
                if opes[batch_idxes] in self.num_ope_biases_batch[batch_idxes]:     # 0首工序
                    # 1.op_st_ma_time矩阵的工序的位置，置为开始时间
                    self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = opes_star_time  # 当前工序加工的机床时间
                    # 2.opes_time矩阵的工序的位置，置为完工时间
                    self.opes_time[batch_idxes, opes[batch_idxes]] = opes_star_time + proc_times[batch_idxes]
                else:                                                               # 非首工序
                    # 1.op_st_ma_time矩阵的工序的上一个位置，置为开始时间
                    self.opes_time[batch_idxes, opes[batch_idxes] - 1] = opes_star_time
                    # 2.cal_cumul_adj_batch，行[:上一个位置] 列[本位置:]，置为0
                    self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0
                # 3.1.3 读取加班信息
                is_work_schedled = self.feat_opes_batch[batch_idxes, 7, :]  # 加班信息
                # 3.1.4 计算同job的其他未加工工序的开始时间
                mean_proc_time = self.opes_time[batch_idxes]
                estimate_times = torch.bmm((mean_proc_time).unsqueeze(0).unsqueeze(0), self.cal_cumul_adj_batch[batch_idxes, :, :].unsqueeze(0)).squeeze()  # 除去选择的工序，计算同job其他工序得时间(开始时间)，估计计划外操作的开始时间
                # 3.1.5 只对首个工序操作，对首个工序加上实际的时间
                self.feat_opes_batch[batch_idxes, 5, :] = self.op_st_ma_time[batch_idxes] + estimate_times  # 实际的开始时间
                # 3.1.6 对开始的时间标准化
                self.feat_opes_batch[batch_idxes, 5, :] = amend_star_time(self.num_jobs,
                                                                          self.nums_ope_batch[batch_idxes, :].unsqueeze(0),
                                                                          self.num_ope_biases_batch[batch_idxes].unsqueeze(0),
                                                                          self.feat_opes_batch[batch_idxes, 5,:].unsqueeze(0)).squeeze()
                # 3.1.7 计算结束时间
                end_time = self.feat_opes_batch[batch_idxes, 5, :] + self.feat_opes_batch[batch_idxes, 2, :]
                # 3.1.8 对结束时间标准化
                end_times = amend_end_time(end_time.unsqueeze(0), self.feat_opes_batch[batch_idxes, 2, :].unsqueeze(0), is_work_schedled.unsqueeze(0)).squeeze()
                # 3.1.9 取出每个job的最后完工时间
                end_time_batch = end_times.gather(0, self.end_ope_biases_batch[batch_idxes, :])  # 取每个工件最后一个工序完成时间（此工件的最大值）
                self.feat_opes_batch[batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch.unsqueeze(0), self.opes_appertain_batch[batch_idxes, :].unsqueeze(0))
            # 3.2 可用时间 < 加工时间
            else:
                # 3.2.1 工序为可中断
                if is_inter == 1:
                    # 1.计算工序的开始时间，max(机床时间， 上一个工序完工时间)
                    opes_star_time = torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]])
                    # 2.判断操作工序是否是job的首个工序，用于矩阵相乘估算每个工序的完工时间
                    if opes[batch_idxes] in self.num_ope_biases_batch[batch_idxes]:     # 首工序
                        self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = opes_star_time                             # 当前工序加工的机床时间
                        self.opes_time[batch_idxes, opes[batch_idxes]] = opes_star_time + proc_times[batch_idxes]       # 当前工序的结束时间，下一个工序的开始时间
                    else:                                                               # 非首工序
                        self.opes_time[batch_idxes, opes[batch_idxes] - 1] = opes_star_time                             # 上一个工序设置为开始时间
                        self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0
                    # 3.读取加班信息
                    is_work_schedled = self.feat_opes_batch[batch_idxes, 7, :]                      # 加班信息
                    # 4.计算同job的其他未加工工序的开始时间
                    mean_proc_time = self.opes_time[batch_idxes]                                    # 根据operation第2维的估计时间，估计未加工工序开始、结束时间
                    estimate_times = torch.bmm((mean_proc_time).unsqueeze(0).unsqueeze(0), self.cal_cumul_adj_batch[batch_idxes, :, :].unsqueeze(0)).squeeze()  # 除去选择的工序，计算同job其他工序得时间(开始时间)，估计计划外操作的开始时间，estimate start time of unscheduled opes(start_times + mean_proc_time).unsqueeze(1)=Size([4, 1, 49])
                    # 5.只对首个工序操作，对首个工序加上实际的时间
                    self.feat_opes_batch[batch_idxes, 5, :] = estimate_times + self.op_st_ma_time[batch_idxes]  # 改变各工序的开始时间
                    # 6.对开始的时间标准化
                    self.feat_opes_batch[batch_idxes, 5, :] = amend_star_time(self.num_jobs,
                                                                              self.nums_ope_batch[batch_idxes,:].unsqueeze(0),
                                                                              self.num_ope_biases_batch[batch_idxes].unsqueeze(0),
                                                                              self.feat_opes_batch[batch_idxes, 5,:].unsqueeze(0)).squeeze()
                    # 7.计算结束时间
                    end_time = self.feat_opes_batch[batch_idxes, 5, :] + self.feat_opes_batch[batch_idxes, 2,:]
                    # 8.结束时间标准化
                    end_times = amend_end_time(end_time.unsqueeze(0), self.feat_opes_batch[batch_idxes, 2, :].unsqueeze(0), is_work_schedled.unsqueeze(0)).squeeze()
                    # 取出每个job的最后完工时间
                    end_time_batch = end_times.gather(0, self.end_ope_biases_batch[batch_idxes,:])  # 取每个工件最后一个工序完成时间（此工件的最大值）
                    self.feat_opes_batch[batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch.unsqueeze(0),self.opes_appertain_batch[batch_idxes, :].unsqueeze(0))
                # 3.2.2 工序为不可中断
                if is_inter == 0:
                    # 3.2.2.1 可用时间 < 加工时间 <= 可用时间+4
                    if u < proc_times[batch_idxes] <= u+4:  # 出现加班、延期加工
                        a = random.uniform(0, 1)
                        # 1.采用加班处理
                        if (bool(6 <= u <= 8)) | ((a <= self.paras['add_work_parameter']) & (bool(proc_times[batch_idxes] <= 8))):
                            # 1.工序开始时间
                            opes_star_time = torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]])  # 开始时间
                            # 2.记录第几天加班
                            ma_day = opes_star_time.div(24, rounding_mode='trunc')  # 在这一天进行加班
                            # 3.计算需要加班的时间
                            add_time[batch_idxes] = proc_times[batch_idxes] - u # 加班的时间用于加班惩罚
                            # 4.将工序加班的信息写入特征向量中
                            self.feat_opes_batch[batch_idxes, 7, opes[batch_idxes]] = 1  # 加班信息写入特征向量
                            # 5.加班信息
                            is_work_schedled = self.feat_opes_batch[batch_idxes, 7, :]
                            # 6.判断是否是首个工序
                            if opes[batch_idxes] in self.num_ope_biases_batch[batch_idxes]:
                                self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = opes_star_time
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24
                            else:
                                self.opes_time[batch_idxes, opes[batch_idxes] - 1] = opes_star_time
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0  # 用于正常
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes], opes[batch_idxes] + 1:] = 0  # 加班
                            # 7.计算同job的其他未加工工序的开始时间
                            mean_proc_time = self.opes_time[batch_idxes]  # 根据operation第2维的估计时间，估计未加工工序开始、结束时间
                            estimate_times = torch.bmm((mean_proc_time).unsqueeze(0).unsqueeze(0), self.cal_cumul_adj_batch[batch_idxes, :, :].unsqueeze(0)).squeeze()  # 除去选择的工序，计算同job其他工序得时间(开始时间)，估计计划外操作的开始时间，estimate start time of unscheduled opes(start_times + mean_proc_time).unsqueeze(1)=Size([4, 1, 49])
                            # 8.只对首个工序操作，对首个工序加上实际的时间
                            self.feat_opes_batch[batch_idxes, 5, :] = self.op_st_ma_time[batch_idxes] + estimate_times  # 改变各工序的开始时间
                            # 9.开始时间标准化
                            self.feat_opes_batch[batch_idxes, 5, :] = amend_star_time(self.num_jobs,
                                                                                      self.nums_ope_batch[batch_idxes, :].unsqueeze(0),
                                                                                      self.num_ope_biases_batch[batch_idxes].unsqueeze(0),
                                                                                      self.feat_opes_batch[batch_idxes, 5, :].unsqueeze(0)).squeeze()
                            # 10.结束时间
                            end_time = self.feat_opes_batch[batch_idxes, 5, :] + self.feat_opes_batch[batch_idxes, 2, :]
                            # 11.结束时间标准化
                            end_times = amend_end_time(end_time.unsqueeze(0), self.feat_opes_batch[batch_idxes, 2, :].unsqueeze(0), is_work_schedled.unsqueeze(0)).squeeze()
                            end_time_batch = end_times.gather(0, self.end_ope_biases_batch[batch_idxes,:])  # 取每个工件最后一个工序完成时间（此工件的最大值）
                            self.feat_opes_batch[batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch.unsqueeze(0), self.opes_appertain_batch[batch_idxes, :].unsqueeze(0))
                        # 2.采用延期处理
                        else:
                            # 1.工序开始时间
                            opes_star_time = torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]])
                            # 2.当前的天数
                            ma_day = opes_star_time.div(24, rounding_mode='trunc')  # 当前天数
                            # 3.延迟的时间
                            daly_time[batch_idxes] = proc_times[batch_idxes]
                            # 4.是否延期加班，计算延期之后加班的时间
                            add_time[batch_idxes] = torch.where(proc_times[batch_idxes] > 8, (proc_times[batch_idxes] - 8.0).float(), torch.tensor(0.0).float())    # 加班的时间用于加班惩罚
                            if add_time[batch_idxes] > 0:  # 延期加班
                                # 加班信息写入特征向量
                                self.feat_opes_batch[batch_idxes, 7, opes[batch_idxes]] = 1
                            # 5.加班信息
                            is_work_schedled = self.feat_opes_batch[batch_idxes, 7, :]
                            # 6.判断是否是首个工序
                            if opes[batch_idxes] in self.num_ope_biases_batch[batch_idxes]:
                                self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24  # 当前工序加工的机床时间
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24 + proc_times[batch_idxes]
                            else:
                                self.opes_time[batch_idxes, opes[batch_idxes] - 1] = (ma_day + 1) * 24
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0
                            # 7.计算同job的其他未加工工序的开始时间
                            mean_proc_time = self.opes_time[batch_idxes]  # 根据operation第2维的估计时间，估计未加工工序开始、结束时间
                            estimate_times = torch.bmm((mean_proc_time).unsqueeze(0).unsqueeze(0), self.cal_cumul_adj_batch[batch_idxes, :, :].unsqueeze(0)).squeeze()  # 除去选择的工序，计算同job其他工序得时间(开始时间)，估计计划外操作的开始时间，estimate start time of unscheduled opes(start_times + mean_proc_time).unsqueeze(1)=Size([4, 1, 49])
                            # 8.计算同job的其他未加工工序的开始时间
                            self.feat_opes_batch[batch_idxes, 5, :] = self.op_st_ma_time[batch_idxes] + estimate_times  # 改变各工序的开始时间
                            # 9.开始时间标准化
                            self.feat_opes_batch[batch_idxes, 5, :] = amend_star_time(self.num_jobs,
                                                                                      self.nums_ope_batch[batch_idxes, :].unsqueeze(0),
                                                                                      self.num_ope_biases_batch[batch_idxes].unsqueeze(0),
                                                                                      self.feat_opes_batch[batch_idxes, 5, :].unsqueeze(0)).squeeze()
                            # 10.计算结束时间
                            end_time = self.feat_opes_batch[batch_idxes, 5, :] + self.feat_opes_batch[batch_idxes, 2, :]
                            # 11.标准化结束时间
                            end_times = amend_end_time(end_time.unsqueeze(0), self.feat_opes_batch[batch_idxes, 2, :].unsqueeze(0), is_work_schedled.unsqueeze(0)).squeeze()
                            end_time_batch = end_times.gather(0, self.end_ope_biases_batch[batch_idxes,:])  # 取每个工件最后一个工序完成时间（此工件的最大值）
                            self.feat_opes_batch[batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch.unsqueeze(0), self.opes_appertain_batch[batch_idxes, :].unsqueeze(0))
                    # 3.2.2.2 可用时间+4 < 加工时间，延期、延期加班
                    if proc_times[batch_idxes] > u + 4:
                        # 1.工序开始时间
                        opes_star_time = torch.max(self.ma_time[batch_idxes, mas[batch_idxes]], self.la_op_com_T[batch_idxes, jobs[batch_idxes]])
                        # 2.第几天加班
                        ma_day = opes_star_time.div(24, rounding_mode='trunc')  # 在这一天进行加班
                        # 3.记录延期时间
                        daly_time[batch_idxes] = proc_times[batch_idxes]
                        # 4.记录延期之后加班时间
                        add_time[batch_idxes] = torch.where(proc_times[batch_idxes] > 8, (proc_times[batch_idxes] - 8.0).float(), torch.tensor(0.0).float())
                        # 5.延期加班
                        if add_time[batch_idxes] > 0:  # 延期加班
                            self.feat_opes_batch[batch_idxes, 7, opes[batch_idxes]] = 1  # 加班信息写入特征向量
                        #
                        is_work_schedled = self.feat_opes_batch[batch_idxes, 7, :]  # 加班信息
                        if opes[batch_idxes] in self.num_ope_biases_batch[batch_idxes]:
                            # 首个工序
                            if add_time[batch_idxes] > 0:  # 延期加班
                                self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 2) * 24
                            else:  # 延期
                                self.op_st_ma_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 1) * 24 + proc_times[batch_idxes]
                        else:
                            if add_time[batch_idxes] > 0:  # 延期加班
                                self.opes_time[batch_idxes, opes[batch_idxes] - 1] = (ma_day + 1) * 24
                                self.opes_time[batch_idxes, opes[batch_idxes]] = (ma_day + 2) * 24
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes], opes[batch_idxes] + 1:] = 0
                            else:  # 延期
                                self.opes_time[batch_idxes, opes[batch_idxes] - 1] = (ma_day + 1) * 24
                                self.cal_cumul_adj_batch[batch_idxes, :opes[batch_idxes] - 1, opes[batch_idxes]:] = 0
                        is_scheduled = self.feat_opes_batch[batch_idxes, 0, :]  # 第0维状态，记录全部工序的加工情况，被选择的置为1
                        mean_proc_time = self.opes_time[batch_idxes]  # 处理时间
                        estimate_times = torch.bmm((mean_proc_time).unsqueeze(0).unsqueeze(0), self.cal_cumul_adj_batch[batch_idxes, :, :].unsqueeze(0)).squeeze()  # 除去选择的工序，计算同job其他工序得时间(开始时间)，估计计划外操作的开始时间，estimate start time of unscheduled opes(start_times + mean_proc_time).unsqueeze(1)=Size([4, 1, 49])
                        self.feat_opes_batch[batch_idxes, 5, :] = estimate_times + self.op_st_ma_time[batch_idxes]  # 改变各工序的开始时间
                        self.feat_opes_batch[batch_idxes, 5, :] = amend_star_time(self.num_jobs,
                                                                                  self.nums_ope_batch[batch_idxes,:].unsqueeze(0),
                                                                                  self.num_ope_biases_batch[batch_idxes].unsqueeze(0),
                                                                                  self.feat_opes_batch[batch_idxes, 5,:].unsqueeze(0)).squeeze()
                        end_time = self.feat_opes_batch[batch_idxes, 5, :] + self.feat_opes_batch[batch_idxes,2, :]
                        end_times = amend_end_time(end_time.unsqueeze(0), self.feat_opes_batch[batch_idxes, 2, :].unsqueeze(0), is_work_schedled.unsqueeze(0)).squeeze()
                        end_time_batch = end_times.gather(0, self.end_ope_biases_batch[batch_idxes,:])  # 取每个工件最后一个工序完成时间（此工件的最大值）
                        self.feat_opes_batch[batch_idxes, 4, :] = convert_feat_job_2_ope(end_time_batch.unsqueeze(0),self.opes_appertain_batch[batch_idxes, :].unsqueeze(0))
            end_t_batch.append(end_times.clone())
        end_times_batch = torch.stack(end_t_batch)
        self.opes_end_times = copy.deepcopy(end_times_batch)                    # opes得结束时间
        self.proc_times_avr = copy.deepcopy(self.feat_opes_batch[:, 2, :])      # opes得处理时间

        #　对于加班的工序时间，没有标准处理，也就是工序的结束时间停留在(1.标准区域 2.加班区域)，所以先判断一下，结束点落在那里了
        # 加班信息
        self.opes_added = self.feat_opes_batch[:, 7, :]
        # 计算每个job的last_opes的完工时间，如果完工落在加班时间，那么置为下一天的开始，否则不变
        self.la_op_com_T[self.batch_idxes, jobs] = torch.where(end_times_batch[self.batch_idxes, opes] % 24 > 8,
                                                               (end_times_batch[self.batch_idxes, opes].div(24,rounding_mode='trunc')+1)*24,
                                                               end_times_batch[self.batch_idxes, opes])
        # 计算机床未利用时间，工序的开始时间-当前机器时间-（（开始天数-机器天数）*16）：防止延期加工的，
        unwork_time = self.feat_opes_batch[self.batch_idxes, 5, opes] - self.ma_time[self.batch_idxes, mas] \
                                                        - ((torch.div(self.feat_opes_batch[self.batch_idxes, 5, opes], 24, rounding_mode='trunc')
                                                        - torch.div(self.ma_time[self.batch_idxes, mas], 24, rounding_mode='trunc'))*16)
        # 计算机床未利用的时间
        self.ma_unwork_time[self.batch_idxes, mas] = unwork_time + self.ma_unwork_time[self.batch_idxes, mas]
        self.feat_mas_batch[self.batch_idxes, 4, :] = self.ma_unwork_time[self.batch_idxes, :]
        # 改变机床时间
        # 计算工序完工对应的天数
        a = end_times_batch[self.batch_idxes, opes].div(24, rounding_mode='trunc')
        # 对于加班的完成时间不在标准内，机床时间设置成下一天的开始
        self.ma_time[self.batch_idxes, mas] = torch.where((end_times_batch[self.batch_idxes, opes] % 24) < 8,
                                                           end_times_batch[self.batch_idxes, opes],
                                                           (a+1)*24)
        # 计算工人正常工作的时间
        self.worker_time[self.batch_idxes, mas] = (self.ma_time[self.batch_idxes, mas].div(24, rounding_mode='trunc')*8) + self.ma_time[self.batch_idxes, mas]%24
        # 计算机器当天可用的时间
        self.feat_mas_batch[self.batch_idxes, 3, mas] = torch.where((end_times_batch[self.batch_idxes, opes] % 24) < 8,
                                                                    (8.0 - (end_times_batch[self.batch_idxes, opes] % 24)).float(),
                                                                    torch.tensor(8.0).float())
        # 计算机床使用时间的时间
        self.ma_work_time[self.batch_idxes, mas] = self.ma_work_time[self.batch_idxes, mas] + proc_times
        # 计算job完工工序数
        self.op_com[self.batch_idxes, jobs] = self.op_com[self.batch_idxes, jobs] + 1
        # 计算未完工的工序数
        self.op_uncom = self.nums_ope_batch - self.op_com
        # 计算job完工率
        self.com_job_rate = torch.div(self.op_com, self.nums_ope_batch)

        # 更新每个job 的首工序数
        self.ope_step_batch[self.batch_idxes, jobs] += 1
        # job若加工置为T,Size([4, 10])
        self.mask_job_procing_batch[self.batch_idxes, jobs] = True
        # machine 使用置为T,Size([4, 5])
        self.mask_ma_procing_batch[self.batch_idxes, mas] = True
        # 检查每个job的全部工序是否完成
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch+1, True, self.mask_job_finish_batch)
        # 检查每个算例是否完成
        self.done_batch = self.mask_job_finish_batch.all(dim=1)
        # 检查这次batch是否都完成
        self.done = self.done_batch.all()

        # 为了下一步正确的计算得修改好 ope_step_batch
        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch, self.end_ope_biases_batch, self.ope_step_batch)

        # 计算延迟工序，考虑当ope_step_batch+1 > end, 超出
        self.tar_opes = copy.deepcopy(torch.where(end_times > self.feat_opes_batch[:, 8, :], 1, 0))  # 延迟工序
        for batch in range(self.batch_size):
            # 估算延迟工序数
            for j,star,end in zip(range(len(ope_step_batch[batch])), ope_step_batch[batch], self.end_ope_biases_batch[batch]):
                if star > end:      # 完工了
                    self.tar_e_op_ucom[batch][j] = 0
                else:               # 未完工
                    self.tar_e_op_ucom[batch][j] = torch.sum(self.tar_opes[batch][star:end+1])
            # 实际延迟工序数
            for k,st,en,end in zip(range(len(ope_step_batch[batch])), self.num_ope_biases_batch[batch], ope_step_batch[batch], self.end_ope_biases_batch[batch]):
                if st > en:
                    self.tar_a_op_ucom[batch][k] = torch.sum(self.tar_opes[batch][st:end+1])
                else:
                    self.tar_a_op_ucom[batch][k] = torch.sum(self.tar_opes[batch][st:en])
        # 进程程度、延期程度
        urg_opes = (self.job_due_time-self.la_op_com_T).div(self.job_due_time)
        self.feat_opes_batch[:, 9, :] = convert_feat_job_2_ope(urg_opes, self.opes_appertain_batch)

        # 加工时间塞入operation_feat中
        for i in range(self.num_mas):
            self.feat_opes_batch[:,10+i,:] = self.proc_times_batch[:,:,i]
        # 将下一步待加工的工序时间塞入machine_feat中：
        self.feat_mas_batch[:, 5:, :] = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.shape[-1]))

        # 跟新图节点信息,self.opes_adj_batch
        for batch in range(self.batch_size):
            sta_ope_biases_batch = self.num_ope_biases_batch[batch]     # 每个job的开始的一个工序id
            end_ope_biases_batch = self.end_ope_biases_batch[batch]     # 每个job的最后的一个工序id
            ope_next_biases_batch = ope_step_batch[batch]
            ope_ma_adj_batch = self.ope_ma_adj_batch[batch]
            # 处理工序之间的关系，只处理被调度的工序
            ope = opes[batch]
            job_0 = jobs[batch]
            ope_0 = ope_next_biases_batch[job_0]
            # 遍历非job_0得其他job
            if ope != ope_0:
                for job_1 in range(self.num_jobs):
                    if job_1 == job_0:
                        continue
                    else:
                        for ope_1 in range(sta_ope_biases_batch[job_1], end_ope_biases_batch[job_1]+1):
                            self.opes_adj_batch[batch][ope_0][ope_1] = (ope_1 - sta_ope_biases_batch[job_1]) - (ope_0 - sta_ope_biases_batch[job_0])
            # 处理工序与机床的关系
            self.opes_adj_batch[batch, :, self.num_opes:] = ope_ma_adj_batch.masked_fill(self.ope_ma_adj_batch[batch]==0, float('-inf'))
            # 处理ope的邻接矩阵（带权）
            if ope != end_ope_biases_batch[job_0]:
                self.gat_opes_adj_batch[batch][ope][ope+1] = proc_times[batch]
            self.gat_opes_adj_batch[batch, :, self.num_opes:] = self.proc_times_batch[batch]

        # 保存解
        self.used[self.batch_idxes, (self.N-1).long(), mas] = 1                                                                      # 选用机床
        self.used[self.batch_idxes, (self.N-1).long(), -9] = opes.float()                                                            # 工序数-id
        self.used[self.batch_idxes, (self.N-1).long(), -8] = self.feat_opes_batch[self.batch_idxes, 7, opes]                         # 是否加班
        self.used[self.batch_idxes, (self.N-1).long(), -7] = 1-self.feat_opes_batch[self.batch_idxes, 6, opes]                       # 是否不可中断
        self.used[self.batch_idxes, (self.N-1).long(), -6] = jobs.float()                                                            # job
        self.used[self.batch_idxes, (self.N-1).long(), -5] = self.nums_ope_batch[self.batch_idxes, jobs].float()                     # job的opes数
        self.used[self.batch_idxes, (self.N-1).long(), -4] = (opes-self.num_ope_biases_batch[self.batch_idxes, jobs]+1).float()      # job第几个工序
        self.used[self.batch_idxes, (self.N-1).long(), -3] = proc_times.float()                                                      # 加工时间
        self.used[self.batch_idxes, (self.N-1).long(), -2] = self.feat_opes_batch[self.batch_idxes, 5, opes].float()                 # 开始时间
        self.used[self.batch_idxes, (self.N-1).long(), -1] = end_times_batch[self.batch_idxes, opes].float()                         # 结束时间

        # 改变feat_use_batch，20个特征
        self.day[self.batch_idxes, mas] = self.ma_time[self.batch_idxes, mas].div(24, rounding_mode='trunc')
        # 计算每个机器的加班时间
        self.add_time[self.batch_idxes, mas] = self.add_time[self.batch_idxes, mas] + add_time
        u_k = self.ma_work_time[self.batch_idxes].div(self.ma_time[self.batch_idxes] - self.day[self.batch_idxes,:]*16 + self.add_time[self.batch_idxes])   # 机器工作时间 / (机床时间-非工作时间+加班时间=正常时间+加班时间)
        nan_mask = torch.isnan(u_k)
        u_k[nan_mask] = 0
        self.feat_used_batch[self.batch_idxes, 1] = torch.mean(u_k[self.batch_idxes], dim=1)                       # 机器的平均利用率
        self.feat_used_batch[self.batch_idxes, 2] = torch.std(u_k[self.batch_idxes], dim=1)                        # 机器的平均利用率标准差
        self.feat_used_batch[self.batch_idxes, 3] = torch.sum(self.op_com[self.batch_idxes]).div(self.nums_opes)   # 总工序完成率
        self.feat_used_batch[self.batch_idxes, 4] = torch.mean(self.com_job_rate, dim=1)                           # 每个job的完成率
        self.feat_used_batch[self.batch_idxes, 5] = torch.std(self.com_job_rate, dim=1)                            # 每个job的完成率标准差
        self.feat_used_batch[self.batch_idxes, 6] = torch.mean(self.ma_work_time.div((torch.max(self.ma_work_time, dim=1)[0]).unsqueeze(1).expand_as(self.ma_work_time)), dim=1)  # 机器工作量归一化平均
        self.feat_used_batch[self.batch_idxes, 7] = torch.std(self.ma_work_time.div((torch.max(self.ma_work_time, dim=1)[0]).unsqueeze(1).expand_as(self.ma_work_time)), dim=1)   # 机器工作量归一化平均标准差
        self.feat_used_batch[self.batch_idxes, 8] = torch.div(torch.sum(self.tar_e_op_ucom[self.batch_idxes], dim=1), torch.sum(self.op_uncom[self.batch_idxes], dim=1))          # 估算延迟率
        self.feat_used_batch[self.batch_idxes, 9] = torch.div(torch.sum(self.tar_a_op_ucom[self.batch_idxes], dim=1), torch.sum(self.op_com[self.batch_idxes], dim=1))          # 实际延迟率
        self.feat_used_batch[self.batch_idxes, 10:-3] = self.feat_used_batch[self.batch_idxes, :10] - self.feat_old_used_batch[self.batch_idxes]

        # 保存当前状态
        self.feat_old_used_batch = copy.deepcopy(self.feat_used_batch[self.batch_idxes, :10])

        # 更新部分进度(状态)，记录工件的加工情况、时间，机床的状态时间
        self.schedules_batch[self.batch_idxes, opes, :2] = torch.stack((torch.ones(self.batch_idxes.size(0)), mas), dim=1)      # 记录工序的加工情况（前两维 ： 状态、机床选择）
        self.schedules_batch[self.batch_idxes, :, 2] = self.feat_opes_batch[self.batch_idxes, 5, :]     # 2 开始时间
        self.schedules_batch[self.batch_idxes, :, 3] = end_times_batch                                  # 结束时间

        self.machines_batch[self.batch_idxes, mas, 0] = torch.zeros(self.batch_idxes.size(0))           # 0忙 1闲
        self.machines_batch[self.batch_idxes, mas, 1] = self.ma_time[self.batch_idxes, mas] - (torch.div(self.ma_time[self.batch_idxes, mas], 24, rounding_mode='trunc')*16)
        # self.machines_batch[self.batch_idxes, mas, 1] = self.time[self.batch_idxes] + proc_times      # 当前可用的时间，当前机床上最后一个工序的完成时间的 可用时间(8h不包含加班时间)
        self.machines_batch[self.batch_idxes, mas, 2] += proc_times                                     # 利用时间
        self.machines_batch[self.batch_idxes, mas, 3] = jobs.float()                                    # job id，第几个job

        # 改变feat_mas_batch 的第 0，1，2(同机床的工序邻居，可用时间，非闲置时间与总生产时间的比值) 维数据，Update feature vectors of machines，更新机器的特征向量
        self.feat_mas_batch[self.batch_idxes, 0, :] = torch.count_nonzero(self.ope_ma_adj_batch[self.batch_idxes, :, :], dim=1).float()     # 工序的邻居
        # self.feat_mas_batch[self.batch_idxes, 1, mas] = self.time[self.batch_idxes] + proc_times      # 可用时间 = 当前时间+加工时间
        self.feat_mas_batch[self.batch_idxes, 1, :] = torch.count_nonzero(self.ope_ma_adj_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.shape[-1])), dim=1).float()      # 机床的可用时间，就是下次开始时间
        utiliz = self.machines_batch[self.batch_idxes, :, 2]
        cur_time = self.time[self.batch_idxes, None].expand_as(utiliz)
        utiliz = torch.minimum(utiliz, cur_time)                                                        # 选出当前的最小的时间
        utiliz = utiliz.div(self.time[self.batch_idxes, None] + 1e-9)
        self.feat_mas_batch[self.batch_idxes, 2, :] = utiliz

        # 计算reward，目标值
        # 计算工人工资
        worker_pay = (self.paras['one_mac_workers']*(self.paras['worker_pay']*self.worker_time + self.paras['worker_add_pay']*self.add_time)).sum(dim=1)
        # 机器消耗电费
        machine_pay = (self.ma_work_time*self.paras['work_electric'] + self.ma_unwork_time*self.paras['unwork_electric'] + self.add_time*self.paras['work_add_electric']).sum(dim=1)
        # 目标能耗
        self.ob_energy = worker_pay + machine_pay
        # job完工时间
        c = end_times_batch.gather(1, self.end_ope_biases_batch[self.batch_idxes,:])
        # job的due time
        d = self.feat_opes_batch[:, 8, :].gather(1, self.end_ope_biases_batch[self.batch_idxes, :])
        zero_tensor = torch.zeros_like(c)
        # 平均机器利用率
        self.ob_Uave = 1/torch.mean(u_k[self.batch_idxes], dim=1)
        # 总延误时间
        self.ob_TWT = torch.sum(torch.max(c-d, zero_tensor), dim=1)
        # 平均延迟率
        #self.ob_TR = torch.mean(torch.max(c-d, zero_tensor).div(c), dim=1)
        # 计算总的延迟时间
        self.ob_TR = torch.max(c-d, zero_tensor).sum(dim=1)
        # 机器工作负载标准差
        self.ob_Wstd = torch.std(self.ma_work_time, dim=1)
        max = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]        # 选取最大的加工时间
        # 计算reward 目标
        #self.ob_penalty = max + add_time[self.batch_idxes] * self.paras['add_work_penalty'] + daly_time[self.batch_idxes] * self.paras['delay_work_penalty']
        max_objective = max*objectives[:, 0] + self.ob_energy*objectives[:, 1] + self.ob_TR*objectives[:, 2]
        self.reward_batch = self.max_objective - max_objective    # 差值作为奖励
        self.makespan_batch = max   # 改变makespan
        self.max_objective = max_objective

        # Check if there are still O-M pairs to be processed, otherwise the environment transits to the next time
        flag_trans_2_next_time = self.if_no_eligible()
        while ~((~((flag_trans_2_next_time==0) & (~self.done_batch))).all()):
            self.next_time(flag_trans_2_next_time)
            flag_trans_2_next_time = self.if_no_eligible()

        # Update the vector for uncompleted instances
        mask_finish = (self.N+1) <= self.nums_opes
        if ~(mask_finish.all()):
            self.batch_idxes = torch.arange(self.batch_size)[mask_finish]

        # Update state of the environment，更新环境状态
        self.state.update(self.batch_idxes,
                          self.feat_opes_batch,
                          self.feat_mas_batch,
                          self.feat_used_batch,
                          self.feat_old_used_batch,
                          self.proc_times_batch,
                          self.opes_time,
                          self.gat_opes_adj_batch,
                          self.ope_ma_adj_batch,
                          self.opes_adj_batch,
                          self.mask_job_procing_batch,
                          self.mask_job_finish_batch,
                          self.mask_ma_procing_batch,
                          self.ope_step_batch,
                          self.time,
                          self.ma_time,
                          self.op_st_ma_time,
                          self.ma_work_time,
                          self.la_op_com_T,
                          self.used,
                          self.tar_opes,
                          self.op_com,
                          self.op_uncom,
                          self.opes_end_times,
                          self.proc_times_avr)
        return self.state, self.reward_batch, self.done_batch

    def if_no_eligible(self):
        '''
        检查是否还有O-M对需要处理,Check if there are still O-M pairs to be processed
        '''
        ope_step_batch = torch.where(self.ope_step_batch > self.end_ope_biases_batch,self.end_ope_biases_batch, self.ope_step_batch)# 检查每个工件的首个工序的ID 是否和最后一个工序的ID相同
        op_proc_time = self.proc_times_batch.gather(1, ope_step_batch.unsqueeze(-1).expand(-1, -1, self.proc_times_batch.size(2)))
        ma_eligible = ~self.mask_ma_procing_batch.unsqueeze(1).expand_as(op_proc_time)  # 当前使用的机床为False，每个工序处理的选用机床的信息
        job_eligible = ~(self.mask_job_procing_batch + self.mask_job_finish_batch)[:, :, None].expand_as(op_proc_time) # 当前加工的工件为False
        flag_trans_2_next_time = torch.sum(torch.where(ma_eligible & job_eligible, op_proc_time.double(), 0.0).transpose(1, 2), dim=[1, 2])

        return flag_trans_2_next_time

    def next_time(self, flag_trans_2_next_time):
        '''
        中转到下一次时间,Transit to the next time
        '''
        # 1.判断无可用 & 未完工
        flag_need_trans = (flag_trans_2_next_time==0) & (~self.done_batch)
        # 2.机器时间
        aa = self.ma_time[:,:]
        # 3.机床时间为最后完工最大值+1
        #max = (torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0] + 1.0).unsqueeze(1)
        max = (torch.max(aa, dim=1)[0] + 1.0).unsqueeze(1)
        # 4.ma最大值标准化：
        for i in range(self.batch_size):
            t = max[i]
            add = t % 24
            if add >= 8:
                max[i] = (t.div(24, rounding_mode='trunc') + 1) * 24 + (add - 8)
        # 4.机器小于当前时间置为最大值
        bb = torch.where(aa > self.time[:, None], aa, max)
        # 5.取每个机床的最小时间
        cc = torch.min(bb, dim=1)[0]
        # 6.在time下，检测机器是否完工，完工-空闲-true
        dd = torch.where((aa <= cc[:, None]) & (self.machines_batch[:, :, 0] == 0) & flag_need_trans[:, None], True, False)
        # 7.如果cc最小时间全部==ma的话，就陷入死循环出不来了，判断是否都cc==ma
        for ba in range(self.batch_size):
            # 全部机床时间==最大 & dd全为空闲 & 无可用
            if (cc[ba] == max[ba]) & (~dd[ba]).all() & flag_need_trans[ba]:
                # 换个最大值+1
                bb[ba] = torch.where(aa[ba] > cc[ba], aa[ba], torch.max(bb[ba] + 1.0))
                cc[ba] = torch.min(bb[ba])
                dd[ba] = torch.where((aa[ba] == cc[ba, None]) & (self.machines_batch[ba, :, 0] == 0) & flag_need_trans[ba, None], True, False)
        # 8.改变最小时间
        ee = torch.where(flag_need_trans, cc, self.time)
        self.time = ee
        # 9.将最小时间的机器状态置为1(变成可用状态),根据dd改变数据
        ma = self.machines_batch.transpose(1, 2)
        ma[dd, 0] = 1
        self.machines_batch = ma.transpose(1, 2)
        # 10.计算机床的利用率，机床的使用时间/T
        utiliz = self.machines_batch[:, :, 2]
        cur_time = self.time[:, None].expand_as(utiliz)
        utiliz = torch.minimum(utiliz, cur_time)
        utiliz = utiliz.div(self.time[:, None] + 1e-5)
        self.feat_mas_batch[:, 2, :] = utiliz   # 改变了机器的特征向量 第2维
        # 释放机床上对应的job
        jobs = torch.where(dd, self.machines_batch[:, :, 3].double(), -1.0).float()  # 选择释放的机床，为那个job，其他置为-1
        jobs_index = np.argwhere(jobs.cpu() >= 0).to(self.device)   # jobs 的位置
        job_idxes = jobs[jobs_index[0], jobs_index[1]].long()   # 读取第几个job
        batch_idxes = jobs_index[0] # 读取第几个算例
        # 改变信息
        self.mask_job_procing_batch[batch_idxes, job_idxes] = False     # 将选择出来的job置为F 参与下一次选择
        self.mask_ma_procing_batch[dd] = False   # 把该时间完成的machine置为F 参与下一次选择
        self.mask_job_finish_batch = torch.where(self.ope_step_batch == self.end_ope_biases_batch + 1, True, self.mask_job_finish_batch)

    def reset(self):
        '''
        将环境重置为初始状态Reset the environment to its initial state
        '''
        self.proc_times_batch = copy.deepcopy(self.old_proc_times_batch)
        self.ope_ma_adj_batch = copy.deepcopy(self.old_ope_ma_adj_batch)
        self.unope_ma_adj_batch = copy.deepcopy(self.old_unope_ma_adj_batch)
        self.cal_cumul_adj_batch = copy.deepcopy(self.old_cal_cumul_adj_batch)
        self.opes_time = copy.deepcopy(self.old_opes_time)
        self.feat_opes_batch = copy.deepcopy(self.old_feat_opes_batch)
        self.feat_mas_batch = copy.deepcopy(self.old_feat_mas_batch)
        self.feat_used_batch = copy.deepcopy(self.old_feat_used_batch)
        self.state = copy.deepcopy(self.old_state)
        self.job_due_time = copy.deepcopy(self.old_job_due_time)
        self.feat_old_used_batch = copy.deepcopy(self.feat_used_batch[:, :10])
        self.opes_adj_batch = copy.deepcopy(self.old_opes_adj_batch )
        self.gat_opes_adj_batch = copy.deepcopy(self.old_gat_opes_adj_batch)

        self.batch_idxes = torch.arange(self.batch_size)
        self.time = torch.zeros(self.batch_size)
        self.worker_time = torch.zeros(size=(self.batch_size, self.num_mas))  # 工人正常时间
        self.day = torch.zeros(size=(self.batch_size, self.num_mas))  # 机器正常时间
        self.ma_time = torch.zeros(size=(self.batch_size, self.num_mas))    # 记录每个机床的时间，就是下一个工序加工的最早时间看，如果加班，这个机器时间记录的是下一个最早的时间
        self.op_st_ma_time = torch.zeros(size=(self.batch_size, self.num_opes))    # 记录当前工序加工时的机床时间
        self.ma_work_time = torch.zeros(size=(self.batch_size, self.num_mas))
        self.ma_unwork_time = torch.zeros(size=(self.batch_size, self.num_mas))  # 记录每个机床的空闲时间(在工作时间内)
        self.la_op_com_T = torch.zeros(size=(self.batch_size, self.num_jobs))
        self.N = torch.zeros(self.batch_size)
        self.ope_step_batch = copy.deepcopy(self.num_ope_biases_batch)

        self.tar_e_op_ucom = torch.zeros(size=(self.batch_size, self.num_jobs))         # 估计迟到的工序数(未加工的工序)
        self.tar_a_op_ucom = torch.zeros(size=(self.batch_size, self.num_jobs))         # 实际迟到的工序数(已加工的工序)
        self.com_job_rate = torch.zeros(size=(self.batch_size, self.num_jobs))          # job的完工率
        self.add = torch.zeros(size=(self.batch_size, self.num_mas))                    # 计算机器平均利用率用到

        self.ob_TWT = torch.zeros(self.batch_size)                                      # 总加权延误
        self.ob_Uave = torch.zeros(self.batch_size)                                     # 平均机器利用率
        self.ob_Wstd = torch.zeros(self.batch_size)                                     # 机器工作负载
        self.ob_energy = torch.zeros(self.batch_size)                                   # 总能耗：工人能耗+机器能耗，工人能耗=时间*工人+机器*电费
        self.ob_TR = torch.zeros(self.batch_size)                                          # 延迟率
        self.op_com = torch.zeros(size=(self.batch_size, self.num_jobs))                # 已经完成的工序
        self.op_uncom = self.nums_ope_batch - self.op_com                               # 未完成的工序
        self.add_time = torch.zeros(size=(self.batch_size, self.num_mas))               # 记录每个job的总加班时间

        self.mask_job_procing_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_job_finish_batch = torch.full(size=(self.batch_size, self.num_jobs), dtype=torch.bool, fill_value=False)
        self.mask_ma_procing_batch = torch.full(size=(self.batch_size, self.num_mas), dtype=torch.bool, fill_value=False)
        self.schedules_batch = torch.zeros(size=(self.batch_size, self.num_opes, 4))
        self.schedules_batch[:, :, 2] = self.feat_opes_batch[:, 5, :]
        end_time = self.feat_opes_batch[:, 5, :] + self.feat_opes_batch[:, 2, :]
        end_times = amend_end_time(end_time[self.batch_idxes], self.feat_opes_batch[:, 2, :], self.feat_opes_batch[:, 7, :])
        self.schedules_batch[:, :, 3] = end_times
        self.opes_end_times = copy.deepcopy(end_times)
        self.proc_times_avr = copy.deepcopy(self.feat_opes_batch[:, 2, :])
        # 估算延迟的工序数
        self.tar_opes = torch.where(end_times > self.feat_opes_batch[:, 8, :], 1, 0)
        for batch in range(self.batch_size):
            self.tar_e_op_ucom[batch] = torch.tensor([torch.sum(self.tar_opes[batch][star:end+1]) for star, end in zip(self.ope_step_batch[batch], self.end_ope_biases_batch[batch])])
            self.tar_a_op_ucom[batch] = torch.tensor([torch.sum(self.tar_opes[batch][star:end+1]) for star, end in zip(self.num_ope_biases_batch[batch], self.ope_step_batch[batch])])

        self.machines_batch = torch.zeros(size=(self.batch_size, self.num_mas, 4))
        self.machines_batch[:, :, 0] = torch.ones(size=(self.batch_size, self.num_mas))
        self.makespan_batch = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]  # shape: (batch_size)
        self.ob_penalty = torch.max(self.feat_opes_batch[:, 4, :], dim=1)[0]
        #objectives = F.softmax(torch.randn(self.batch_size, 3), dim=1)
        # 工人工资
        worker_pay = (self.paras['one_mac_workers']*(self.paras['worker_pay']*self.makespan_batch.unsqueeze(1).expand(-1, self.num_mas) + self.paras['worker_add_pay']*self.add_time)).sum(dim=1)
        # 机器消耗电费
        machine_pay = (self.makespan_batch.unsqueeze(1).expand(-1, self.num_mas)*self.paras['work_electric'] + self.ma_unwork_time*self.paras['unwork_electric'] + self.add_time*self.paras['work_add_electric']).sum(dim=1)
        # 目标能耗
        self.ob_energy = worker_pay + machine_pay
        max_objective = self.makespan_batch + self.ob_energy+ self.ob_TR
        self.max_objective = max_objective

        self.done_batch = self.mask_job_finish_batch.all(dim=1)
        self.used = torch.zeros(size=(self.batch_size, self.num_opes, self.num_mas + 9))
        return self.state

    def render(self, mode='human'):
        '''
        Deprecated in the final experiment
        '''
        if self.show_mode == 'draw':
            num_jobs = self.num_jobs
            num_mas = self.num_mas
            print(sys.argv[0])
            color = read_json("./utils/color_config")["gantt_color"]
            if len(color) < num_jobs:
                num_append_color = num_jobs - len(color)
                color += ['#' + ''.join([random.choice("0123456789ABCDEF") for _ in range(6)]) for c in
                          range(num_append_color)]
            write_json({"gantt_color": color}, "./utils/color_config")
            for batch_id in range(self.batch_size):
                schedules = self.schedules_batch[batch_id].to('cpu')
                fig = plt.figure(figsize=(10, 6))
                fig.canvas.set_window_title('Visual_gantt')
                axes = fig.add_axes([0.1, 0.1, 0.72, 0.8])
                y_ticks = []
                y_ticks_loc = []
                for i in range(num_mas):
                    y_ticks.append('Machine {0}'.format(i))
                    y_ticks_loc.insert(0, i + 1)
                labels = [''] * num_jobs
                for j in range(num_jobs):
                    labels[j] = "job {0}".format(j + 1)
                patches = [mpatches.Patch(color=color[k], label="{:s}".format(labels[k])) for k in range(self.num_jobs)]
                axes.cla()
                axes.set_title(u'FJSP Schedule')
                axes.grid(linestyle='-.', color='gray', alpha=0.2)
                axes.set_xlabel('Time')
                axes.set_ylabel('Machine')
                axes.set_yticks(y_ticks_loc, y_ticks)
                axes.legend(handles=patches, loc=2, bbox_to_anchor=(1.01, 1.0), fontsize=int(14 / pow(1, 0.3)))
                axes.set_ybound(1 - 1 / num_mas, num_mas + 1 / num_mas)
                for i in range(int(self.nums_opes[batch_id])):
                    id_ope = i
                    idx_job, idx_ope = self.get_idx(id_ope, batch_id)
                    id_machine = schedules[id_ope][1]
                    axes.barh(id_machine,
                             0.2,
                             left=schedules[id_ope][2],
                             color='#b2b2b2',
                             height=0.5)
                    axes.barh(id_machine,
                             schedules[id_ope][3] - schedules[id_ope][2] - 0.2,
                             left=schedules[id_ope][2]+0.2,
                             color=color[idx_job],
                             height=0.5)
                plt.show()
        return

    def get_idx(self, id_ope, batch_id):
        '''
        Get job and operation (relative) index based on instance index and operation (absolute) index
        '''
        idx_job = max([idx for (idx, val) in enumerate(self.num_ope_biases_batch[batch_id]) if id_ope >= val])
        idx_ope = id_ope - self.num_ope_biases_batch[batch_id][idx_job]
        return idx_job, idx_ope

    def validate_gantt(self):
        '''
        验证计划是否可行,Verify whether the schedule is feasible
        '''
        ma_gantt_batch = [[[] for _ in range(self.num_mas)] for __ in range(self.batch_size)]   # 为每个算例、机床 设置数组
        for batch_id, schedules in enumerate(self.schedules_batch):     # 选择算例
            for i in range(int(self.nums_opes[batch_id])):  # 选择每个工序
                step = schedules[i]
                ma_gantt_batch[batch_id][int(step[1])].append([i, step[2].item(), step[3].item()]) # 把工序分好机床：序号，开始时间，结束时间
        proc_time_batch = self.proc_times_batch
        added_time_batch = self.opes_added
        # 检查机器上是否有重叠时间、加工时间是否正确，Check whether there are overlaps and correct processing times on the machine
        flag_proc_time = 0      # 记录处理时间错误的工序数
        flag_ma_overlap = 0     # 时间重叠错误的机器上的工序数
        flag = 0
        for k in range(self.batch_size):
            ma_gantt = ma_gantt_batch[k]    # 选择分好堆 的算例
            proc_time = proc_time_batch[k]
            for i in range(self.num_mas):   # for i machines
                ma_gantt[i].sort(key=lambda s: s[1])    # 对每个机器中得工序，按开始时间(小->大)排序
                for j in range(len(ma_gantt[i])):   # 每个机器得有多少工序数
                    if (len(ma_gantt[i]) <= 1) or (j == len(ma_gantt[i])-1):
                        break
                    if ma_gantt[i][j][2]>ma_gantt[i][j+1][1]:   # 检查当前机床工序的完成时间 > 下一个的开始时间
                        flag_ma_overlap += 1
                    if (ma_gantt[i][j][2]-ma_gantt[i][j][1] - proc_time[ma_gantt[i][j][0]][i]) % 16 != 0:  # 结束时间-开始时间 ！= proc_time的处理时间
                        flag_proc_time += 1
                    flag += 1

        # 检查作业顺序和重叠部分，Check job order and overlap
        flag_ope_overlap = 0
        for k in range(self.batch_size):
            schedule = self.schedules_batch[k]  # 取算例 对应的工序安排
            nums_ope = self.nums_ope_batch[k]   # 每个job的工序数
            num_ope_biases = self.num_ope_biases_batch[k]   # 每个job的首工序的排序数
            for i in range(self.num_jobs):  # for i jobs
                if int(nums_ope[i]) <= 1:
                    continue
                for j in range(int(nums_ope[i]) - 1):
                    step = schedule[num_ope_biases[i]+j]    # 首工序排序数+第0，1，2...工序数
                    step_next = schedule[num_ope_biases[i]+j+1] # 下一工序
                    if step[3] > step_next[2]:  # 检查当前job 本工序的完成时间 > 下一工序的开始时间
                        flag_ope_overlap += 1

        # 检查是否有计划外操作，Check whether there are unscheduled operations
        flag_unscheduled = 0
        for batch_id, schedules in enumerate(self.schedules_batch):
            count = 0
            for i in range(schedules.size(0)):  # 算例
                if schedules[i][0]==1:  # 检查是否全部工序的状态都置为1
                    count += 1
            add = 0 if (count == self.nums_opes[batch_id]) else 1
            flag_unscheduled += add

        if flag_ma_overlap + flag_ope_overlap + flag_proc_time + flag_unscheduled != 0:
            return False, self.schedules_batch
        else:
            return True, self.schedules_batch

    def close(self):
        pass
