import copy
import json
import os
import random
import time as time

import gym
import pandas as pd
import torch
import numpy as np

import pynvml
import PPO_model
from env.load_data import nums_detec
from sorting import distribute_solution
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def main():
    # PyTorch初始化,PyTorch initialization
    # gpu_tracker = MemTracker() #用于监控gpu的内存, gpu_tracker = MemTracker()  # Used to monitor memory (of gpu)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if device.type=='cuda':
        torch.cuda.set_device(device)
        torch.set_default_tensor_type('torch.cuda.FloatTensor')
    else:
        torch.set_default_tensor_type('torch.FloatTensor')
    print("PyTorch device: ", device.type)
    torch.set_printoptions(precision=None, threshold=np.inf, edgeitems=None, linewidth=None, profile=None, sci_mode=False)

    # Load config and init objects
    with open("./config.json", 'r') as load_f:
        load_dict = json.load(load_f)
    env_paras = load_dict["env_paras"]
    model_paras = load_dict["model_paras"]
    train_paras = load_dict["train_paras"]
    test_paras = load_dict["test_paras"]
    env_paras["device"] = device
    model_paras["device"] = device
    env_test_paras = copy.deepcopy(env_paras)
    num_ins = test_paras["num_ins"]
    if test_paras["sample"]:
        env_test_paras["batch_size"] = test_paras["num_sample"]         # num_sample就是train的batch_size
    else:
        env_test_paras["batch_size"] = 1

    data_path = "./data_test/{0}/".format(test_paras["data_path"])
    test_files = os.listdir(data_path)
    test_files.sort(key=lambda x: x[:-4])
    # 测试几个算例
    test_files = test_files[:num_ins]
    mod_files = os.listdir('./model/')[:]

    # 1.读取训练好的模型
    memories = PPO_model.Memory()
    model = PPO_model.PPO(model_paras, train_paras)
    rules = test_paras["rules"]
    envs = []  # 存储多个环境,Store multiple environments
    rules_files = []
    # 检测并向“规则”添加模型,Detect and add models to "rules"
    if "DRL" in rules:      # 取前两层网络
        folder_path = './model/'
        subdirs = [subdir for subdir in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, subdir)) and not subdir.startswith('.')]     # 遍历文件夹下的子文件夹
        sorted_subdirs = sorted(subdirs, key=lambda x: int(x))  # 根据子文件夹名称进行排序
        # 1.2 读取非支配层前几层的模型
        top_subdirs = sorted_subdirs[:6]    # 获取前3个子文件夹路径
        for subdir_name in top_subdirs:
            subdir_path = os.path.join(folder_path, subdir_name)
            for file_name in os.listdir(subdir_path):
                if file_name.endswith('.pt'):
                    rules.append(file_name)
                    rules_files.append(subdir_path)
    if len(rules) != 1:
        if "DRL" in rules:
            rules.remove("DRL")

    # 2.生成测试的数据文件
    str_time = time.strftime("%Y%m%d_%H%M%S", time.localtime(time.time()))
    save_path = './save/test_{0}'.format(str_time)
    os.makedirs(save_path)
    path_makespan = save_path + '/makespan_{0}.xlsx'.format(str_time)
    path_time = save_path + '/time_{0}.xlsx'.format(str_time)
    writer = pd.ExcelWriter(path_makespan, model='w', engine='openpyxl')  # Makespan data storage path
    writer_time = pd.ExcelWriter(path_time, mode='w', engine='openpyxl')  # time data storage path
    file_name = [test_files[i] for i in range(10, num_ins)]
    data_file = pd.DataFrame(file_name, columns=["file_name"])
    data_file.to_excel(writer, sheet_name='Sheet1', index=False)
    writer.save()
    #writer.close()
    data_file.to_excel(writer_time, sheet_name='Sheet1', index=False)
    writer_time.save()
    # ins-by-ins, rules-by-rules, count-by-count
    st_time = time.time()
    # 3.循环测试算例
    for i_ins in range(10,num_ins):                                    # 遍历每个算例

        test_file = data_path + test_files[i_ins]
        with open(test_file) as file_object:
            line = file_object.readlines()
            ins_num_jobs, ins_num_mas, ins_num_opes, ins_num_unopes = nums_detec(line)
        env_test_paras["num_jobs"] = ins_num_jobs
        env_test_paras["num_mas"] = ins_num_mas
        # 环境对象已经存在,Environment object already exists
        if len(envs) == num_ins:
            env = envs[i_ins]
        # 创建环境对象,Create environment object
        else:
            # 清理现有环境,Clear the existing environment
            meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
            if meminfo.used / meminfo.total > 0.7:
                envs.clear()

            # 3.1 采用哪种方法测试算例，第一种方法：选择几个并行一块进行
            # DRL-S,每个env包含一个实例的多个(=num_sample)副本, 意思就是num_sample 个算例相同each env contains multiple (=num_sample) copies of one instance
            if test_paras["sample"]:
                env = gym.make('fjsp-v0', case=[test_file] * test_paras["num_sample"], env_paras=env_test_paras, data_source='file')
            # DRL-G, each env contains one instance
            else:
                env = gym.make('fjsp-v0', case=[test_file], env_paras=env_test_paras, data_source='file')
            envs.append(copy.deepcopy(env))
            print(f"Create env: {test_files[i_ins]}---------------------------------------------------------------------")
        # 3.2 并行算例，循环遍历模型
        objects = []
        solutions = []
        solutions_time = []
        ins_start = time.time()
        for i_rule, i_files in zip(rules, rules_files):        # 遍历每个模型
            # 负荷训练模型,Load trained model
            if i_rule.endswith('.pt'):
                if device.type == 'cuda':
                    model_CKPT = torch.load(f"{i_files}/" + i_rule)    # 训练好的网络权重
                else:
                    model_CKPT = torch.load(f"{i_files}/" + i_rule, map_location='cpu')
                print('loading checkpoint:', i_rule)
                model.policy.load_state_dict(model_CKPT)   # 将保存在 model_CKPT 字典中的权重参数加载到 model.policy 模型
                model.policy_old.load_state_dict(model_CKPT)
            print('rule:', i_rule)
            # 3.2.1一个模型遍历几次
            for i_s in range(1):                                # 每个模型遍历几次
                # DRL-S
                if test_paras["sample"]:
                    object, so_time = schedule(env, model, memories, flag_sample=test_paras["sample"])
                    objects.extend(object.tolist())
                    solutions.extend(env.used.tolist())
                    solutions_time.append(so_time)
                # DRL-G
                else:
                    time_s = []
                    makespan_s = []  # 事实上，DRL-G得到的结果并没有改变，In fact, the results obtained by DRL-G do not change
                    for j in range(test_paras["num_average"]):
                        object, so_time = schedule(env, model, memories)
                        makespan_s.append(object)
                        time_s.append(so_time)
                    objects.append(makespan_s)
                    solutions_time.append(time_s)
                print(f"finished solutions {(i_s+1)*2}  spend time: {so_time}")
                env.reset()
            end_time = time.time()
            #if (end_time - ins_start) > 20:
                #break
        ins_end = time.time()
        print(f"finished instances {test_files[i_ins]} speed time: {ins_end-ins_start}----------------------------------")
        solutions_time.insert(0, ins_end - ins_start)       # 0：总时间
        # 3.3对生成的解非支配排序
        # 初始化一个空的支配集合字典和支配计数器字典
        domination_set = {}         # 支配的集合
        domination_counter = {}     # 支配计数器
        # 初始化每个模型的支配集合和支配计数器
        for i in range(len(objects)):
            domination_set[i] = set()
            domination_counter[i] = 0
        # 对每对模型进行比较，确定支配关系
        obs = torch.tensor(objects)
        for i in range(len(obs)):
            for j in range(len(obs)):
                if i != j:
                    if ((obs[i] < obs[j]).all()) \
                            or ((obs[i] == obs[j]).sum() == 1 and (obs[i] < obs[j]).sum() == 2) \
                            or ((obs[i] == obs[j]).sum() == 2 and (obs[i] < obs[j]).sum() == 1):  # i -> j
                        domination_set[i].add(j)
                    elif (obs[i] > obs[j]).all() \
                            or ((obs[i] == obs[j]).sum() == 1 and (obs[i] > obs[j]).sum() == 2) \
                            or ((obs[i] == obs[j]).sum() == 2 and (obs[i] > obs[j]).sum() == 1):  # j -> i
                        domination_counter[i] += 1
        fronts = []
        cu_front = []
        while len(domination_counter) > 0:
            cu_front = [model_idx for model_idx, count in domination_counter.items() if count == 0]  # 0 层非支配前沿
            # 从支配计数器中移除当前前沿模型
            for model_idx in cu_front:
                del domination_counter[model_idx]
                # 更新被当前模型支配的模型的支配计数器
                for dominated_idx in domination_set[model_idx]:
                    domination_counter[dominated_idx] -= 1
            fronts.append(cu_front)
        fronts_objs = [[] for _ in range(len(fronts))]
        # 3.4将解存入文件保存
        # 目标存入objects.txt
        file_name = './solution/' + f"{ins_num_jobs}-{ins_num_mas}/" +os.path.splitext(test_files[i_ins])[0]  # 解文件名
        if not os.path.exists(file_name):
            os.makedirs(file_name)
        objects_name = file_name + "/objects.txt"
        f_o = open(objects_name, "w")
        ins = [ins_num_jobs, ins_num_mas, ins_num_opes, ins_num_unopes]
        in_ls = (" ".join([str(val) for val in ins]))
        f_o.write(in_ls + '\n')
        time_name = file_name + "/times.txt"
        f_t = open(time_name, "w")
        # 时间存入time.txt
        inss = [ins_num_jobs, ins_num_mas, ins_num_opes, ins_num_unopes, test_paras["num_sample"]]
        in_lss = (" ".join([str(val) for val in inss]))
        f_t.write(in_lss + '\n')
        for t in solutions_time:
            f_t.write(str(t) + '\n')
        f_t.close()
        for count in range(len(fronts)):
            solution_name = file_name + f"/{count}.txt"                            # 存第几层放解
            ins_info = [ins_num_jobs, ins_num_mas, ins_num_opes, ins_num_unopes]
            ins_lines = (" ".join([str(val) for val in ins_info]))
            with open(solution_name, 'w') as f:
                f.write(ins_lines + '\n')
                for idx in fronts[count]:
                    object_info = (" ".join([str(val) for val in objects[idx]]))
                    f.write(object_info + '\n')
                    f_o.write(object_info + '\n')
                    fronts_objs[count].append(objects[idx])
                f_o.write('\n')
                f.write('\n')
                for idx in fronts[count]:
                    for row in solutions[idx]:
                        line = " ".join(str(element) for element in row)
                        f.write(line + '\n')
                    f.write('\n')
            f.close()
        f_o.close()
        # Save makespan and time data to files
        data = pd.DataFrame(index=range(len(fronts_objs)), columns=["objects"])
        for i, front in enumerate(fronts_objs):
            data.at[i, "objects"] = front
        transposed_data = data.transpose()
        transposed_data.to_excel(writer, sheet_name='Sheet1', index=False, header=False, startrow=i_ins + 1, startcol=1)
        writer.save()
        data = pd.DataFrame(index=range(len(solutions_time)), columns=["time"])
        for i, front in enumerate(solutions_time):
            data.at[i, "time"] = front
        transposed_data = data.transpose()
        transposed_data.to_excel(writer_time, sheet_name='Sheet1', index=False, header=False, startrow=i_ins + 1, startcol=1)
        writer_time.save()
    print(f"finished all {num_ins} instances speed time：{time.time()-st_time}")
    writer.close()
    writer_time.close()
def schedule(env, model, memories, flag_sample=False):
    # 获取状态和完成信号，Get state and completion signal
    state = env.state
    dones = env.done_batch
    done = False  # 一开始未完成，Unfinished at the beginning
    i = 0
    last_time = time.time()
    while ~done:
        i += 1
        with torch.no_grad():
            actions, object = model.policy_old.act(state, memories, flag_sample=flag_sample, flag_train=False)
        state, rewards, dones = env.step(actions, object)  # environment transit
        done = dones.all()
    spend_time = time.time() - last_time  # 解决此环境(实例)所花费的时间,The time taken to solve this environment (instance)
    #print("all_action_spend_time: ", spend_time)
    makespan_batch = copy.deepcopy(env.makespan_batch)
    TR_batch = copy.deepcopy(env.ob_TR)
    energy_batch = copy.deepcopy(env.ob_energy)
    object = torch.stack([makespan_batch, energy_batch, TR_batch], dim=1)
    # 验证解决方案,Verify the solution
    gantt_result = env.validate_gantt()[0]
    if not gantt_result:
        print("Scheduling Error！！！！！！")
    return object, spend_time


if __name__ == '__main__':
    main()