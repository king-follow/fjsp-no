import os
import shutil

def non_dominated_sorting(models_name, models_scores, save_path):
    models_path = save_path + "/models"
    models_names = models_name
    models_scores = models_scores
    # 初始化一个空的支配集合字典和支配计数器字典
    domination_set = {}             # 支配的集合
    domination_counter = {}         # 支配计数器
    # 初始化每个模型的支配集合和支配计数器
    for i in range(len(models_scores)):
        domination_set[i] = set()
        domination_counter[i] = 0
    # 对每对模型进行比较，确定支配关系
    for i in range(len(models_scores)):
        for j in range(len(models_scores)):
            if i != j:
                if ((models_scores[i] < models_scores[j]).all()) \
                        or ((models_scores[i] == models_scores[j]).sum()==1 and (models_scores[i] < models_scores[j]).sum()==2)\
                        or ((models_scores[i] == models_scores[j]).sum()==2 and (models_scores[i] < models_scores[j]).sum()==1):    # i -> j
                    domination_set[i].add(j)
                elif (models_scores[i] > models_scores[j]).all() \
                        or ((models_scores[i] == models_scores[j]).sum()==1 and (models_scores[i] > models_scores[j]).sum()==2)\
                        or ((models_scores[i] == models_scores[j]).sum()==2 and (models_scores[i] > models_scores[j]).sum()==1):  # j -> i
                    domination_counter[i] += 1
    # 根据支配计数器确定非支配前沿，一层一层得将前面给去除
    fronts = []
    current_front = []
    while len(domination_counter) > 0:
        current_front = [model_idx for model_idx, count in domination_counter.items() if count == 0]        # 0 层非支配前沿
        # 从支配计数器中移除当前前沿模型
        for model_idx in current_front:
            del domination_counter[model_idx]
            # 更新被当前模型支配的模型的支配计数器
            for dominated_idx in domination_set[model_idx]:
                domination_counter[dominated_idx] -= 1
        fronts.append(current_front)
    # 将模型参数分类
    for count in range(len(fronts)):
        files_name = models_path + f'/{count}'
        if not os.path.exists(files_name):
            os.makedirs(files_name)
        for idx in fronts[count]:
            source_path = models_path + f"/{models_names[idx]}"
            target_path = files_name
            shutil.move(source_path, target_path)
"""
    # models_scores: 目标值列表
    # models_names: 模型名称列表
    # 将目标值和模型名称组合成元组
    model_data = list(zip(models_scores, models_names))
"""
def distribute_solution(array_size, total_value):
    initial_value = total_value // array_size
    remaining_value = total_value % array_size

    count = [initial_value] * array_size
    for i in range(remaining_value):
        count[i] += 1
    return count