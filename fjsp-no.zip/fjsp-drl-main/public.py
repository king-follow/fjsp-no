import torch
import copy
import math
import numpy as np

def amend_star_time(num_jobs, nums_ope_batch, num_ope_biases_batch, tensor):
    star_times = []
    tens = tensor
    for b, batch in enumerate(nums_ope_batch):
        times = []
        for j in range(num_jobs):
            for i in range(batch[j]):
                id = num_ope_biases_batch[b, j] + i
                time = tens[b, id]
                t = tens[b, id]
                while ~(((time / 24).long() * 24) <= time <= ((time / 24).long() * 24 + 8)):
                    time = (((time / 24).long() + 1) * 24) + (time - ((time / 24).long() * 3 + 1) * 8)
                times.append(time)
                ad_time = time - t
                for n in range(id + 1, num_ope_biases_batch[b, j]+batch[j]):
                    tens[b, n] = tens[b, n] + ad_time
        star_times.append(torch.Tensor(times).clone())
    return torch.stack(star_times)
def amend_end_time(tensor, proc_time, is_work_schedled):
    end_times = []
    for batch, proc_batch, is_wo_scheled in zip(tensor, proc_time, is_work_schedled):
        times=[]
        l = len(batch)
        for i in range(l):
            time = batch[i]
            pro = proc_batch[i]
            is_work = is_wo_scheled[i]
            if is_work == 0:
                # 不加班的 需要处理时间
                if proc_batch[i] > 16:
                    star_time = time - pro               # 开始时间
                    add_time = (((star_time / 24).long()) * 24 + 8) - star_time
                    rema_time = pro - add_time
                    #time = (rema_time / 8) * 24 + (rema_time % 8) + (((star_time / 24).long()) * 24 + 8)
                    time = (((star_time / 24).long() + 1)*24) + (((rema_time // 8) * 24) + (rema_time % 8))
                while ~(((time / 24).long() * 24) <= time <= ((time / 24).long() * 24 + 8)):
                    time = (((time / 24).long() + 1) * 24) + (time - ((time / 24).long() * 3 + 1) * 8)
            times.append(time)
        end_times.append(torch.Tensor(times).clone())
    return torch.stack(end_times)




















