import gym
import env
import PPO_model
import torch
import time
import os
import copy

def get_validate_env(env_paras):
    '''
    Generate and return the validation environment from the validation set ()
    '''
    file_path = "./data_dev/{0}{1}/".format(env_paras["num_jobs"], str.zfill(str(env_paras["num_mas"]), 2))
    valid_data_files = os.listdir(file_path)
    for i in range(len(valid_data_files)):
        valid_data_files[i] = file_path+valid_data_files[i]
    env = gym.make('fjsp-v0', case=valid_data_files, env_paras=env_paras, data_source='file')
    return env

def validate(env_paras, env, model_policy):
    '''
    在培训期间验证策略，其过程类似于测试,Validate the policy during training, and the process is similar to test
    '''
    start = time.time()
    batch_size = env_paras["batch_size"]
    memory = PPO_model.Memory()
    print('There are {0} dev instances.'.format(batch_size))  # validation set is also called development set
    state = env.state
    done = False
    dones = env.done_batch
    while ~done:
        with torch.no_grad():
            actions, object = model_policy.act(state, memory, flag_sample=False, flag_train=False)
        state, rewards, dones = env.step(actions, object)
        done = dones.all()
    gantt_result = env.validate_gantt()[0]
    vali_time = time.time() - start
    if not gantt_result:
        print("Scheduling Error！！！！！！")
    makespan = copy.deepcopy(env.makespan_batch.mean())
    makespan_batch = copy.deepcopy(env.makespan_batch)
    TR = copy.deepcopy(env.ob_TR.mean())
    TR_batch = copy.deepcopy(env.ob_TR)
    cost = copy.deepcopy(env.ob_energy.mean())
    cost_batch = copy.deepcopy(env.ob_energy)
    Uave = copy.deepcopy(env.ob_Uave.mean())
    Uave_batch = copy.deepcopy(env.ob_Uave)
    total_mean = makespan + cost + TR
    env.reset()
    print('---validating time: ', vali_time)
    print(f'---validate maksps: {makespan}-{cost}-{TR}---{total_mean}---')
    return makespan, makespan_batch, cost, cost_batch, TR, TR_batch, total_mean, vali_time
