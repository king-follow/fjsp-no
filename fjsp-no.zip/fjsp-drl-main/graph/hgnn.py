import torch
from torch import nn
from torch.nn import Identity
import torch.nn.functional as F
import math

# 定义 GAT 注意力系数模型
class GATedge(nn.Module):
    '''
    Machine node embedding
    '''
    def __init__(self,
                 in_feats,
                 out_feats,
                 num_head,
                 feat_drop=0.,
                 attn_drop=0.,
                 negative_slope=0.2,
                 residual=False,
                 activation=None):
        '''
        :param in_feats: tuple, input dimension of (operation node, machine node)
        :param out_feats: Dimension of the output (machine embedding)
        :param num_head: Number of heads
        '''
        super(GATedge, self).__init__()
        self._num_heads = num_head  # single head is used in the actual experiment
        self._in_src_feats = in_feats[0]
        self._in_dst_feats = in_feats[1]
        self._out_feats = out_feats

        if isinstance(in_feats, tuple):
            self.fc_src = nn.Linear(
                self._in_src_feats, out_feats * num_head, bias=False)
            self.fc_dst = nn.Linear(
                self._in_dst_feats, out_feats * num_head, bias=False)
            self.fc_edge = nn.Linear(
                1, out_feats * num_head, bias=False)
        else:
            self.fc = nn.Linear(
                self._in_src_feats, out_feats * num_head, bias=False)
        self.attn_l = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        self.attn_r = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        self.attn_e = nn.Parameter(torch.rand(size=(1, num_head, out_feats), dtype=torch.float))
        self.feat_drop = nn.Dropout(feat_drop)
        self.attn_drop = nn.Dropout(attn_drop)
        self.leaky_relu = nn.LeakyReLU(negative_slope)

        # Deprecated in final experiment
        if residual:
            if self._in_dst_feats != out_feats:
                self.res_fc = nn.Linear(
                    self._in_dst_feats, num_head * out_feats, bias=False)
            else:
                self.res_fc = Identity()
        else:
            self.register_buffer('res_fc', None)
        self.reset_parameters()
        self.activation = activation

    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')
        if hasattr(self, 'fc'):
            nn.init.xavier_normal_(self.fc.weight, gain=gain)
        else:
            nn.init.xavier_normal_(self.fc_src.weight, gain=gain)
            nn.init.xavier_normal_(self.fc_dst.weight, gain=gain)
            nn.init.xavier_normal_(self.fc_edge.weight, gain=gain)
        nn.init.xavier_normal_(self.attn_l, gain=gain)
        nn.init.xavier_normal_(self.attn_r, gain=gain)
        nn.init.xavier_normal_(self.attn_e, gain=gain)

    def forward(self, ope_ma_adj_batch, unope_ma_adj_batch, batch_idxes, feat):
        # 机器节点和操作节点分别使用两个线性变换，Two linear transformations are used for the machine nodes and operation nodes, respective
        # In linear transformation, an W^O (\in R^{d \times 7}) for \mu_{ijk} is equivalent to
        #   W^{O'} (\in R^{d \times 6}) and W^E (\in R^{d \times 1}) for the nodes and edges respectively
        if isinstance(feat, tuple):
            h_src = self.feat_drop(feat[0]) # 就是一个对神经元随即丢弃，因为p=0.0丢弃不起作用
            h_dst = self.feat_drop(feat[1])
            if not hasattr(self, 'fc_src'):         # self 是否包含 ‘fc_src’
                self.fc_src, self.fc_dst = self.fc, self.fc
            feat_src = self.fc_src(h_src)   # Size([4, 53, 8])      # operations feat_embedding
            feat_dst = self.fc_dst(h_dst)   # Size([4, 5, 8])       # machines feat_embedding
        else:
            # Deprecated in final experiment
            h_src = h_dst = self.feat_drop(feat)
            feat_src = feat_dst = self.fc(h_src).view(
                -1, self._num_heads, self._out_feats)
        feat_edge = self.fc_edge(feat[2].unsqueeze(-1))     # Size([4, 53, 5, 8])

        # 求计算注意系数,Calculate attention coefficients，unsqueeze(-1)升维
        el = (feat_src * self.attn_l).sum(dim=-1).unsqueeze(-1)     # Size([4, 53, 1])
        er = (feat_dst * self.attn_r). sum(dim=-1).unsqueeze(-1)     # Size([4, 5, 1])
        ee = (feat_edge * self.attn_l).sum(dim=-1).unsqueeze(-1)    # Size([4, 53, 5, 1])
        el_add_ee = ope_ma_adj_batch[batch_idxes].unsqueeze(-1) * el.unsqueeze(-2) + ee  # Size([4, 53, 5, 1])
        a = el_add_ee + ope_ma_adj_batch[batch_idxes].unsqueeze(-1) * er.unsqueeze(-3)  # Size([4, 53, 5, 1])
        eijk = self.leaky_relu(a)   # Size([4, 53, 5, 1])
        ekk = self.leaky_relu(er + er)  # Size([4, 5, 1])

        # 归一化注意系数,Normalize attention coefficients
        mask = torch.cat((ope_ma_adj_batch[batch_idxes].unsqueeze(-1)==1,
                          torch.full(size=(ope_ma_adj_batch[batch_idxes].size(0), 1,
                                           ope_ma_adj_batch[batch_idxes].size(2), 1),
                                     dtype=torch.bool, fill_value=True)), dim=-3)   # Size([4, 54, 5, 1]),bool
        e = torch.cat((eijk, ekk.unsqueeze(-3)), dim=-3)    # Size([4, 54, 5, 1]), ekk.unsqueeze(-3) = Size([4, 1, 5, 1])
        e[~mask] = float('-inf')    # ~ bool取反 = 负无穷,根据mask，将e中对应mask为False的置为负无穷
        alpha = F.softmax(e.squeeze(-1), dim=-2)
        alpha_ijk = alpha[..., :-1, :]  # Size([4, 53, 5]),每一组去掉最后一行,因为左后一行是ekk参数
        alpha_kk = alpha[..., -1, :].unsqueeze(-2)  # Size([4, 1, 5])

        # 计算回机嵌入,Calculate an return machine embedding
        Wmu_ijk = feat_edge + feat_src.unsqueeze(-2)    # Size([4, 53, 5, 8]),feat_src.unsqueeze(-2)=Size([4, 53, 1, 8])
        a = Wmu_ijk * alpha_ijk.unsqueeze(-1)   # Size([4, 53, 5, 8]),alpha_ijk.unsqueeze(-1)=Size([4, 53, 5, 1])
        b = torch.sum(a, dim=-3)    # Size([4, 5, 8]),对应53个工序分5个机床8位数据相加
        c = feat_dst * alpha_kk.squeeze().unsqueeze(-1) # Size([4, 5, 8])
        nu_k_prime = torch.sigmoid(b+c) # torch.Size([4, 5, 8]),将所有信息都集中在了 对应的5个机床上
        return nu_k_prime   # Size([30, 3, 8])

# mlp 定义
class MLPsim(nn.Module):
    '''
    Part of operation node embedding
    '''
    def __init__(self,
                 in_feats,
                 out_feats,
                 hidden_dim,
                 num_head,
                 feat_drop=0.,
                 attn_drop=0.,
                 negative_slope=0.2,
                 residual=False):
        '''
        :param in_feats: Dimension of the input vectors of the MLPs
        :param out_feats: Dimension of the output (operation embedding) of the MLPs
        :param hidden_dim: Hidden dimensions of the MLPs
        :param num_head: Number of heads
        '''
        super(MLPsim, self).__init__()
        self._num_heads = num_head
        self._in_feats = in_feats
        self._out_feats = out_feats

        self.feat_drop = nn.Dropout(feat_drop)
        self.attn_drop = nn.Dropout(attn_drop)
        self.leaky_relu = nn.LeakyReLU(negative_slope)
        self.project = nn.Sequential(
            nn.Linear(self._in_feats, hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Linear(hidden_dim, self._out_feats),
        )

        # Deprecated in final experiment
        if residual:
            if self._in_dst_feats != out_feats:
                self.res_fc = nn.Linear(
                    self._in_dst_feats, self._num_heads * out_feats, bias=False)
            else:
                self.res_fc = Identity()
        else:
            self.register_buffer('res_fc', None)

    def forward(self, feat):
        c = self.project(feat)
        return c

class GATLayer(nn.Module):
    def __init__(self, in_features, out_features, num_heads):
        super(GATLayer, self).__init__()
        self.num_heads = num_heads
        self.head_dim = out_features // num_heads
        self.fc_layers = nn.ModuleList([nn.Linear(in_features, self.head_dim) for _ in range(self.num_heads)])
        self.attn_fc_layers = nn.ModuleList([nn.Linear(out_features, 1) for _ in range(self.num_heads)])

        gain = nn.init.calculate_gain('relu')
        for i in range(self.num_heads):
            nn.init.xavier_normal_(self.fc_layers[i].weight, gain=gain)
            nn.init.xavier_normal_(self.attn_fc_layers[i].weight, gain=gain)

    def forward(self, feat, adj):
        head_outputs = []
        for i in range(self.num_heads):
            x_i = self.fc_layers[i](feat)
            e_i = F.leaky_relu(self.attn_fc_layers[i](torch.cat([x_i, x_i], dim=-1)), negative_slope=0.2)   # 2,16,1,Attention scores
            c_i = e_i.masked_fill(adj == 0, -1e9)
            alpha_i = F.softmax(c_i+adj, dim=1)
            head_output_i = alpha_i.sum(dim=-1).unsqueeze(-1) * x_i
            head_outputs.append(head_output_i)
        # Concatenate the outputs of all heads
        output = torch.cat(head_outputs, dim=-1)
        return output

class GATModel(nn.Module):
    def __init__(self,
                 in_dims,
                 mlp_out_dim,
                 gat_out_dim,
                 num_layers,
                 num_heads,
                 ):
        super(GATModel, self).__init__()
        self.in_opes_dim = in_dims[0]
        self.in_mas_dim = in_dims[1]
        self.mlp_out_dim = mlp_out_dim
        self.gat_out_dim = gat_out_dim
        self.num_layers = num_layers
        self.num_heads = num_heads

        self.mlp_o = nn.Linear(self.in_opes_dim, self.mlp_out_dim)
        self.mlp_m = nn.Linear(self.in_mas_dim, self.mlp_out_dim)

        self.gat_layers_o = nn.ModuleList([GATLayer(self.mlp_out_dim, self.gat_out_dim, self.num_heads) for _ in range(num_layers)])
        self.gat_layers_m = nn.ModuleList([GATLayer(self.mlp_out_dim, self.gat_out_dim, self.num_heads) for _ in range(num_layers)])

    def forward(self, feats, adjs):
        opes_feat = feats[0]
        mas_feat = feats[1]
        opes_adj = adjs[0]
        mas_adj = adjs[1].transpose(1,2)
        o_f = self.mlp_o(opes_feat)
        m_f = self.mlp_m(mas_feat)
        for layer_o in self.gat_layers_o:
            o_f = layer_o(o_f, opes_adj)
        #out_opes_feat = F.elu(o_f)  # Apply activation function
        out_opes_feat = torch.sigmoid(o_f)
        for layer_m in self.gat_layers_m:
            m_f = layer_m(m_f, mas_adj)
        #out_mas_feat = F.elu(m_f)  # Apply activation function
        out_mas_feat = torch.sigmoid(m_f)
        return out_opes_feat, out_mas_feat

class SATLayer(nn.Module):
    def __init__(self, in_features, out_features, num_heads):
        super(SATLayer, self).__init__()
        self.num_heads = num_heads
        self.head_dim = out_features // num_heads

        self.q_layers = nn.ModuleList([nn.Linear(in_features, self.head_dim) for _ in range(self.num_heads)])
        self.k_layers = nn.ModuleList([nn.Linear(in_features, self.head_dim) for _ in range(self.num_heads)])
        self.v_layers = nn.ModuleList([nn.Linear(in_features, self.head_dim) for _ in range(self.num_heads)])

        gain = nn.init.calculate_gain('relu')
        for i in range(self.num_heads):
            nn.init.xavier_normal_(self.q_layers[i].weight, gain=gain)
            nn.init.xavier_normal_(self.k_layers[i].weight, gain=gain)
            nn.init.xavier_normal_(self.v_layers[i].weight, gain=gain)

    def forward(self, feat):
        head_outputs = []
        for i in range(self.num_heads):
            q_i = self.q_layers[i](feat)
            k_i = self.k_layers[i](feat)
            v_i = self.v_layers[i](feat)
            c_i = q_i.matmul(k_i.transpose(1, 2)).div(math.sqrt(self.head_dim))
            alpha_i = F.softmax(c_i, dim=0)
            head_output_i = alpha_i*v_i  # Weighted sum of features
            head_outputs.append(head_output_i)
        output = torch.cat(head_outputs, dim=-1)
        return output

class SATModel(nn.Module):
    def __init__(self,
                 in_dims,
                 mlp_out_dim,
                 sat_out_dim,
                 num_layers,
                 num_heads,):
        super(SATModel, self).__init__()
        self.in_tol_dim = in_dims
        self.mlp_out_dim = mlp_out_dim
        self.sat_out_dim = sat_out_dim
        self.num_layers = num_layers
        self.num_heads = num_heads

        self.mlp_t = nn.Linear(self.in_tol_dim, self.mlp_out_dim)
        self.sat_layers_t = nn.ModuleList([SATLayer(self.mlp_out_dim, self.sat_out_dim, self.num_heads) for _ in range(num_layers)])

    def forward(self, feats):
        tol_feat = feats
        t_f = self.mlp_t(tol_feat)
        for layer_t in self.sat_layers_t:
            t_f = layer_t(t_f)
        out_tol_feats = torch.sigmoid(t_f)
        return out_tol_feats



# 定义 LSTM 模型
class MultiLSTMMergeAttention(nn.Module):
    def __init__(self,
                 in_feats,  # 输入维度
                 output_dim,  # 输出维度
                 hidden_dim,  # 隐藏层维度
                 num_layers,  # 隐藏层层数
                 num_head,  # 注意力头数
                 feat_dropout=0.,  # 如果非0，就在除了最后一层的其它层都插入Dropout层，默认为0
                 attn_dropout=0.,
                 negative_slope=0.2,  # 负斜率
                 activation=None,
                 bias=True,
                 batch_first=True,  # True,(batch,seq_length,feature); Flase,(seq_length,batch,feature)
                 bidirectional=False,  # 如果设置为 True, 则表示双向 LSTM，默认为 False
                 ):
        super(MultiLSTMMergeAttention, self).__init__()
        self.in_src_feats_dim = in_feats[0]
        self.in_dst_feats_dim = in_feats[1]
        self.in_used_feat_dim = in_feats[2]
        self.output_dim = output_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.num_head = num_head

        self.num_feat = len(in_feats)
        # 构建LSTM网络, feat_ops, feat_mas, feat_a
        self.lstm_list = nn.ModuleList([nn.LSTM(dim, self.hidden_dim, self.num_layers, batch_first=True) for dim in in_feats])

        # 构建attention权重的计算线性层, W_o, W_m, W_a
        self.W = nn.ModuleList(nn.Linear(hidden_dim + in_feats[i], 1) for i in range(len(in_feats)))

        # 构建输出全连接层，pytorch中LSTM网络没有输出层
        self.fc_list = nn.ModuleList(nn.Linear(hidden_dim, output_dim) for _ in range(3))

        # 定义注意力系数参数
        self.attn_o = nn.Parameter(torch.rand(size=(1, num_head, hidden_dim), dtype=torch.float))
        self.attn_m = nn.Parameter(torch.rand(size=(1, num_head, hidden_dim), dtype=torch.float))
        self.attn_a = nn.Parameter(torch.rand(size=(1, num_head, hidden_dim), dtype=torch.float))
        self.feat_drop = nn.Dropout(feat_dropout)
        self.attn_drop = nn.Dropout(attn_dropout)
        self.leaky_relu = nn.LeakyReLU(negative_slope)

        self.reset_parameters()                 # 更新产生的参数，使网络有一个更适合的起点
        self.activation = activation

        self.attns = [self.attn_o, self.attn_m, self.attn_a]



    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')
        nn.init.xavier_normal_(self.W[0].weight, gain=gain)
        nn.init.xavier_normal_(self.W[1].weight, gain=gain)
        nn.init.xavier_normal_(self.W[2].weight, gain=gain)

        nn.init.xavier_normal_(self.attn_o, gain=gain)
        nn.init.xavier_normal_(self.attn_m, gain=gain)
        nn.init.xavier_normal_(self.attn_a, gain=gain)


    def forward(self, feat, init, ope_ma_adj_batch, batch_idxes):
        """
        lstm_input: 1、三维张量:【batch_size, seq_length, input_dim】
                    2、h_init: 【num_layers * num_directions, batch_size, hidden_dim】构建h输入参数   -- 每个batch对应一个隐层
                    3、c_init：【num_layers * num_directions, batch_size, hidden_size】构建c输出参数   -- 每个batch对应一个隐层
        lstm_output: 1、lstm_output：【batch_size, seq_length, hidden_dim】表示隐层到输出层学习参数
                     2、h；【num_layers * num_directions, batch_size, hidden_dim】
                     3、c:【num_layers * num_directions, batch_size, hidden_dim】
        """
        f_out = []
        inits = []
        E = []
        for i, (lstm, w, a) in enumerate(zip(self.lstm_list, self.W, self.attns)):
            lstm_input = feat[i]
            self.h_init = init[i][0]
            self.c_init = init[i][1]
            hx = (self.h_init.contiguous(), self.c_init.contiguous())
            lstm.flatten_parameters()                       # 压缩LSTM层的权重
            lstm.cuda()                                     # 将LSTM模型权重移动到GPU上
            lstm_input = lstm_input.cuda()                  # 将输入数据移到GPU上（假设 lstm_input 是在GPU上的张量）
            lstm_output, (c, h) = lstm(lstm_input, hx)      # lstm计算
            energy = torch.tanh(w(torch.cat((lstm_input, lstm_output), dim=2)))     # v 的计算, w:将特征转化为1维，注意力系数的参数
            e = (energy.matmul(a).sum(dim=-1)).unsqueeze(-1)                        # 用于求 u, a*v = e, 求注意力系数
            E.append(e)
            f_out.append(lstm_output)
            inits.append(torch.stack([c, h], dim=0))        # 本时间的 h_t，作为下一个时间的输入
        # 计算 e
        e_o = E[0]          # 2,30,1
        e_m = E[1]          # 2,4,1
        e_a = E[2]          # 2,1,1
        # 计算 f
        f_o = f_out[0]      # 2,30,256
        f_m = f_out[1]      # 2,4,256
        f_a = f_out[2]      # 2,1,256
        # 计算 u
        u_o = self.leaky_relu(e_o.unsqueeze(-2) * ope_ma_adj_batch[batch_idxes].unsqueeze(-1)
                              + e_m.unsqueeze(-3) * ope_ma_adj_batch[batch_idxes].unsqueeze(-1)
                              + e_a.unsqueeze(-1).expand(-1, e_o.size(1), -1, -1) * ope_ma_adj_batch[batch_idxes].unsqueeze(-1))        # 2,27,4,1
        u_m = self.leaky_relu(e_m + e_m + e_a.expand(-1, e_m.size(1), -1))                                                              # 2,4,1
        u_a = self.leaky_relu(e_a)                                                                                                      # 2,1,1
        # 归一化注意系数,Normalize attention coefficients
        mask = torch.cat((ope_ma_adj_batch[batch_idxes].unsqueeze(-1) == 1,
                          torch.full(size=(ope_ma_adj_batch[batch_idxes].size(0), 2, ope_ma_adj_batch[batch_idxes].size(2), 1), dtype=torch.bool, fill_value=True)),
                            dim=-3)     # Size([2, 30+1+1, 4, 1]),bool
        e = torch.cat((u_o, u_m.unsqueeze(-3), u_a.unsqueeze(-1).expand(-1, -1, u_o.size(2), -1)), dim=-3)  # Size([4, 54, 5, 1]), ekk.unsqueeze(-3) = Size([4, 1, 5, 1])
        e[~mask] = float('-inf')  # ~ bool取反 = 负无穷,根据mask，将e中对应mask为False的置为负无穷
        alpha = F.softmax(e.squeeze(-1), dim=-2)        # 2,32,4
        # 计算 α
        alpha_o = alpha[..., :-2, :].sum(-1).unsqueeze(-1)                  # Size([2, 30, 1]),每一组去掉最后一行,因为左后一行是ekk参数
        alpha_m = alpha[..., -2, :].unsqueeze(-1)                           # Size([2, 4 , 1])
        alpha_a = alpha[..., -1, :].sum(-1).unsqueeze(-1).unsqueeze(-1)     # Size([2, 1 , 1])
        # 计算 c_t = α*f
        c_t = torch.cat((alpha_o * f_o, alpha_m * f_m, alpha_a * f_a), dim=-2)        # Size([2, ops+mas+1 , 256])
        c_o = alpha_o * f_o     # 2,30,256
        c_m = alpha_m * f_m     # 2,4,256
        c_a = alpha_a * f_a     # 2,1,256
        # 全连接层 256->16
        a_t = self.fc_list[0](c_t)      # 2,ops+mas+1,16, torch.sigmoid(), 用于pool
        a_o = self.fc_list[1](c_o)      # 2,30,16
        a_m = self.fc_list[2](c_m)      # 2,4,16
        return a_t, a_o, a_m, torch.stack(inits, dim=0)


